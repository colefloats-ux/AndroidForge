# AndroidTV Launcher — Version 3.0 (Android Studio/Gradle project)

This ZIP is **native Android source code**, not HTML or an APK. It contains Android/Java source, a valid Android Gradle module, the manifest, eight original seasonal background images, eight TV tile graphics, and a GitHub Actions build workflow. The project is designed for a TV-compatible Android source compiler.

## Build a debug APK

Use Java 17, Android SDK Platform 35, Android Gradle Plugin 8.6.1, and Gradle 8.9. In the folder containing `settings.gradle` run:

```bash
gradle assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`. If you are using an iPhone-based cloud service, upload this complete ZIP unchanged; choose **Android Gradle** and **debug APK**. The included `.github/workflows/build-apk.yml` provides an alternative CI build when uploaded to a GitHub repository with Actions enabled.

## Version 3 home screen

- **Compact Roku-inspired AndroidTV home:** AndroidTV title, live clock, left Home / Search / Settings navigation, original ordered app tiles, a right-side All Apps chevron, and the seasonal scenic backgrounds.
- **Eight initial channels:** Live TV (launches DIRECTV), Stremio, Hulu, Disney+, HBO Max, Peacock, Prime Video, and Paramount+. Apps must be installed separately; Live TV deliberately uses the purple TV graphic instead of DIRECTV branding.
- **Golden Verse of the Day:** Replaces the bottom-center Gemini bar. Fetches the publisher's public RSS feed (`https://feeds.feedburner.com/hl-devos-votd`) from VerseOfTheDay.com and falls back to the source website if needed. Shows verse text, Bible book/chapter/verse reference, and translation in a gold rounded card with black lettering. Refreshes once daily in the background, saves the last successfully retrieved verse for offline use, and never blocks the home screen while fetching. Selecting the card opens the full verse and a link to the publisher. The publisher selects one daily verse; the app does not invent or randomly generate Bible passages.
- **Remote long press:** Hold OK/Enter on any channel **3 seconds** for the purple Move / Remove from Home / Cancel menu. Move enters navigation mode (arrows rearrange, OK saves, Back cancels). Remove hides the tile from Home without uninstalling the service. Preferences persist locally. Settings offers **Restore the eight original channel tiles**.
- **Nonstretch graphics:** Wallpaper uses `CENTER_CROP`, so it may fill/crop the TV display. Every channel tile has a fixed **450:288** canvas ratio and artwork uses `FIT_CENTER` instead of `FIT_XY`. A centered 16:9 content layout keeps all logos, text and cards proportional on unusual displays. Your TV's own *Picture Size/Aspect Ratio* setting may still override the whole HDMI output; choose Normal/Original/Just Scan rather than Stretch or Zoom when available.
- **Eight seasonal themes:** Spring petals/butterflies; summer fireflies/water shimmer; autumn sparse leaves and breezy leaves; winter drifting snow and freezing/ice-shattering transitions. Choose Auto/manual themes, reduce intensity, or disable effects in Settings.
- **App speed:** Instant mode (default) launches apps immediately without waiting for seasonal transitions. Optional Cinematic mode completes winter ice and autumn leaf effects before launch. Channel intents are cached; large wallpapers decode on a worker thread, and ambient effects pause while another app is foreground.
- **Launcher setup:** Android Home role request and status, Home-intent registration, system Home fallback, and safe ADB instructions for models that restrict third-party home screens. An ordinary app cannot silently override protected manufacturer defaults.
- **Search:** Sidebar search still finds installed applications, offers TV voice search when supported, and provides Gemini/web options if desired. The separate Gemini search *bar* has been removed from Home.

## Technical configuration

- App id: `com.androidtv.launcher`
- Version: `3.0.0` (`versionCode 4`)
- Min SDK 23; target SDK 32; compile SDK 35; Java 17
- Native Android Views, no remote JavaScript or webview runtime dependencies
- Internet permission is used only for the Verse of the Day feed/page and user-selected links/searches.
- Source: `app/src/main/java/com/androidtv/launcher`
- Images: `app/src/main/res/drawable-nodpi`
- Home-role instructions: `docs/SET_AS_HOME.md`

## Limits and transparency

- The verse feed requires internet for fresh text; the last successful verse is cached offline. If the publisher changes its feed, blocks the device, or has a network outage, the app does not invent a verse. It offers a website link and can retry.
- Source code has been checked for structural validity, but an Android SDK was not available in the authoring environment, so this release is **not claimed to be compiled, installed, or TV-tested**. Verify your APK build logs and test on the device.
- No third-party app can guarantee the manufacturer will allow default Home replacement or that an app will load instantaneously on a given television.
