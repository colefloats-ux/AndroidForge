package com.androidtv.launcher;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.Html;
import android.util.Xml;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.xmlpull.v1.XmlPullParser;

/** Daily verse from Heartlight's public VerseOfTheDay.com RSS feed, with offline cache. */
public final class VerseOfDay {
    private VerseOfDay(){}
    private static final String FEED="https://feeds.feedburner.com/hl-devos-votd";
    private static final String SITE="https://www.verseoftheday.com/";
    private static final AtomicBoolean LOADING=new AtomicBoolean(false);
    private static final Pattern BIBLE_REF=Pattern.compile(
        "\\b((?:(?:[123]|I{1,3})\\s*)?[A-Z][a-z]+(?:\\s+[A-Z]?[a-z]+){0,3}\\s+\\d{1,3}:\\d{1,3}(?:[-–]\\d{1,3})?)\\b");
    private static final String PREF_TEXT="votd_text_v3";
    private static final String PREF_REF="votd_ref_v3";
    private static final String PREF_DATE="votd_date_v3";
    private static final String PREF_TRANSLATION="votd_translation_v3";
    private static final String PREF_ATTEMPT="votd_attempt_v3";

    public interface Listener { void onVerse(Verse verse); }
    public static final class Verse {
        public final String text,reference,translation;
        Verse(String t,String r,String tr){text=t;reference=r;translation=tr;}
    }
    private static String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    public static Verse cached(Context context){
        SharedPreferences p=ThemeConfig.prefs(context);
        String text=p.getString(PREF_TEXT,"");
        String reference=p.getString(PREF_REF,"");
        if(text.isEmpty()||reference.isEmpty())return null;
        return new Verse(text,reference,p.getString(PREF_TRANSLATION,""));
    }
    /** Always invoke the callback on the main UI thread. Never block Home rendering. */
    public static void load(Activity activity,Listener callback){
        SharedPreferences p=ThemeConfig.prefs(activity);
        Verse existing=cached(activity);
        if(existing!=null)callback.accept(existing);
        if(today().equals(p.getString(PREF_DATE,"")))return;
        long lastAttempt=p.getLong(PREF_ATTEMPT,0);
        if(System.currentTimeMillis()-lastAttempt<60000L)return;
        if(!LOADING.compareAndSet(false,true))return;
        p.edit().putLong(PREF_ATTEMPT,System.currentTimeMillis()).apply();
        new Thread(()->{
            Verse fresh=null;
            try{fresh=fromRss();}catch(Exception ignored){}
            // If the feed fails or changes formatting, attempt the originating web page.
            if(fresh==null)try{fresh=fromWebPage();}catch(Exception ignored){}
            if(fresh!=null){
                p.edit().putString(PREF_TEXT,fresh.text).putString(PREF_REF,fresh.reference)
                    .putString(PREF_TRANSLATION,fresh.translation).putString(PREF_DATE,today()).apply();
            }
            final Verse result=fresh;
            LOADING.set(false);
            activity.runOnUiThread(()->{
                if(result!=null)callback.accept(result);
                else if(existing==null)callback.accept(new Verse(
                    "Today's verse is unavailable. Select here to retry or visit VerseOfTheDay.com.",
                    "VerseOfTheDay.com",""));
            });
        },"AndroidTV-daily-verse").start();
    }
    private static HttpURLConnection connect(String url) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setRequestProperty("User-Agent","AndroidTVLauncher/3.0 (+daily verse home widget)");
        c.setRequestProperty("Accept","application/rss+xml, text/xml, text/html;q=0.9, */*;q=0.5");
        c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(4500);c.setReadTimeout(4500);
        if(c.getResponseCode()!=200)throw new java.io.IOException("HTTP "+c.getResponseCode());
        return c;
    }
    private static Verse fromRss() throws Exception {
        HttpURLConnection c=connect(FEED);
        try(InputStreamReader rd=new InputStreamReader(c.getInputStream(),"UTF-8")){
            XmlPullParser parser=Xml.newPullParser();parser.setInput(rd);
            boolean insideItem=false;
            String title="",description="",content="";
            String tag="";
            for(int type=parser.getEventType();type!=XmlPullParser.END_DOCUMENT;type=parser.next()){
                if(type==XmlPullParser.START_TAG){
                    tag=parser.getName();
                    if("item".equalsIgnoreCase(tag)){insideItem=true;title="";description="";content="";}
                    else if(insideItem && ("title".equalsIgnoreCase(tag)||"description".equalsIgnoreCase(tag)||"encoded".equalsIgnoreCase(tag))){
                        String value=parser.nextText();
                        if("title".equalsIgnoreCase(tag))title=value;
                        else if("description".equalsIgnoreCase(tag))description=value;
                        else content=value;
                    }
                }else if(type==XmlPullParser.END_TAG && "item".equalsIgnoreCase(parser.getName())){
                    Verse result=fromFeedItem(title,description,content);
                    if(result!=null)return result;
                    insideItem=false;
                }
            }
            return null;
        }finally{c.disconnect();}
    }
    private static Verse fromFeedItem(String title,String description,String content){
        String plain=deHtml(description.isEmpty()?content:description);
        String header=deHtml(title);
        String ref=findReference(header);
        if(ref==null)ref=findReference(plain);
        if(ref==null)return null;
        String verse=extractVerse(plain,ref);
        if(verse==null && !content.isEmpty())verse=extractVerse(deHtml(content),ref);
        if(verse==null)return null;
        return new Verse(verse,ref,"NIV");
    }
    private static String deHtml(String text){
        if(text==null)return "";
        return (android.os.Build.VERSION.SDK_INT>=24
            ? Html.fromHtml(text,Html.FROM_HTML_MODE_LEGACY)
            : Html.fromHtml(text)).toString()
            .replace('\u00a0',' ').replace('\u200b',' ').trim();
    }
    private static String findReference(String text){
        Matcher m=BIBLE_REF.matcher(text);
        return m.find()?m.group(1).trim():null;
    }
    private static String extractVerse(String raw,String ref){
        String cleaned=raw.replaceAll("(?i)\\b(Thoughts on Today's Verse|My Prayer|Related Topics|Subscribe|Today's Verse Illustrated)\\b[\\s\\S]*$","").trim();
        String[] lines=cleaned.split("[\\r\\n]+");
        for(String line:lines){
            String t=line.trim().replaceAll("\\s+"," ");
            if(t.isEmpty()||t.toLowerCase(Locale.US).startsWith("verse of the day"))continue;
            if(t.equalsIgnoreCase(ref)||t.matches("(?i)^(?:by )?phil ware.*"))continue;
            if(t.length()>18 && !t.contains("http") && !t.toLowerCase(Locale.US).startsWith("copyright") &&
                !t.toLowerCase(Locale.US).startsWith("subscribe")){
                // The devotional's first content paragraph is the Bible verse itself.
                int idx=t.indexOf(ref);
                if(idx>16)t=t.substring(0,idx).trim();
                t=t.replaceAll("^[“\\\"']|[”\\\"']$","").trim();
                if(t.length()>18 && t.length()<600)return t;
            }
        }
        return null;
    }
    private static Verse fromWebPage() throws Exception {
        HttpURLConnection c=connect(SITE);
        try(java.io.BufferedReader rd=new java.io.BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"))){
            StringBuilder html=new StringBuilder();String line;
            while((line=rd.readLine())!=null && html.length()<500000)html.append(line).append('\n');
            String source=html.toString();
            // Site markup occasionally changes. Search common paragraph and heading structures.
            Pattern section=Pattern.compile("(?is)<(?:blockquote|p|div)[^>]*(?:verse|scripture|votd|passage)[^>]*>(.*?)</(?:blockquote|p|div)>");
            Matcher m=section.matcher(source);
            while(m.find()){
                String plain=deHtml(m.group(1));String ref=findReference(plain);
                if(ref==null){
                    // Reference often appears in an adjacent sibling element.
                    String nearby=deHtml(source.substring(m.end(),Math.min(source.length(),m.end()+1500)));
                    ref=findReference(nearby);
                }
                String verse=ref==null?null:extractVerse(plain,ref);
                if(ref!=null&&verse!=null)return new Verse(verse,ref,"NIV");
            }
            // HTML-only fallback: the publisher formats its public home page as
            // a date heading followed by the verse and a dash-prefixed Bible reference.
            String plain=deHtml(source.replaceAll("(?is)<script\\b[^>]*>.*?</script>"," ")
                .replaceAll("(?is)<style\\b[^>]*>.*?</style>"," "));
            String[] lines=plain.split("[\\r\\n]+");
            boolean afterDate=false;
            StringBuilder verse=new StringBuilder();
            for(String line:lines){
                String t=line.trim();if(t.isEmpty())continue;
                if(t.matches("(?i)^for\\s+(Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday).*")){
                    afterDate=true;verse.setLength(0);continue;
                }
                if(!afterDate)continue;
                String ref=findReference(t);
                if(ref!=null && verse.length()>20 && verse.length()<600){
                    return new Verse(verse.toString().trim(),ref,"NIV");
                }
                if(t.toLowerCase(Locale.US).startsWith("thoughts on today's verse"))break;
                if(verse.length()>0)verse.append(' ');
                verse.append(t);
                if(verse.length()>600)break;
            }
            return null;
        }finally{c.disconnect();}
    }
}
