# AndroidTV Launcher v3.0.1 — AndroidForge build fixes

This archive is a **native Android Java/Gradle project**. It is intended for AndroidForge or any Gradle-capable Android build service, not a website-to-APK converter.

## Corrected build blockers

1. **VerseOfDay.java:** The `Listener` interface declares `onVerse(Verse)`. Three incorrect calls to `callback.accept(...)` now use `callback.onVerse(...)`. The old calls were Java compilation errors.
2. **Gradle wrapper:** The previous ZIP provided `gradlew` but omitted `gradle/wrapper/gradle-wrapper.jar`. The incomplete wrapper could fail when AndroidForge chose it. Removed incomplete Gradle wrapper scripts and properties so AndroidForge uses its installed Gradle. The ordinary `settings.gradle`, root `build.gradle`, `app/build.gradle` and `gradle.properties` remain.
3. **Version:** Bumped Android versionCode from 4 to 5 and versionName to 3.0.1. App ID remains `com.androidtv.launcher`.

## How to build on iPhone

1. Open your AndroidForge page and choose this ZIP.
2. Use Debug APK / assembleDebug.
3. If it fails, open **Open run on GitHub**, then open the **Build project** step or **Diagnose failure** and share the actual first error line, or download the `AndroidForge-logs` artifact. The generic `Fail if build failed` line does not show the root cause.

## Verification status

Project files, assets and Java syntax were statically checked. An actual Android SDK / Gradle compilation is not available in this environment. This ZIP is not a compiled APK, and successful installation has not yet been verified.
