# AndroidTV Launcher changelog

## 3.0.0 — Golden Verse / Tile Management / Aspect-Ratio Correction

- Replaced the Gemini home bar with a gold rounded Verse of the Day card, black serif verse lettering, a Bible reference and publisher attribution.
- Added background daily RSS retrieval from VerseOfTheDay.com with local offline cache, HTTP timeouts and web page fallback.
- Added a three-second TV remote OK/Enter long press for the tile context menu, including Move and Remove from Home.
- Added native D-pad tile reorder mode with OK-to-save and Back-to-cancel. Persists order in local preferences.
- Added a Settings option to restore all eight original Home tiles.
- Fixed unwanted horizontal logo stretching: tile images now use FIT_CENTER rather than FIT_XY; all have matching 450x288 canvases.
- Layout coordinates now use a centered 16:9 content plane even on wider or oddly reported TV displays; wallpaper still fills the display with CENTER_CROP.
- Kept the instant app-launch path, 8 seasonal themes, optional cinematic effects, home-role setup and All Apps screen.

## 1.2.0

- Default Home role request and fallback, preloaded launch intents, seasonal performance improvements, revised app tile artwork.
