package com.androidtv.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Optional list of *installed* TV applications, reached from the home-screen chevron. */
public final class AllAppsActivity extends Activity {
    private FrameLayout.LayoutParams position(int width,int height,int gravity,int l,int t,int r,int b){
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(width<0?width:Ui.dp(this,width),height<0?height:Ui.dp(this,height),gravity);
        lp.setMargins(Ui.dp(this,l),Ui.dp(this,t),Ui.dp(this,r),Ui.dp(this,b));return lp;
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        FrameLayout root=new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF30205C,0xFF120F24}));
        TextView title=Ui.label(this,"All Apps",29,Color.WHITE,true);
        root.addView(title,position(-2,50,Gravity.TOP|Gravity.LEFT,55,31,0,0));
        TextView subtitle=Ui.label(this,"Installed TV applications · Press OK to open",15,0xFFD8CEE8,false);
        root.addView(subtitle,position(-2,30,Gravity.TOP|Gravity.LEFT,55,84,0,0));
        ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);
        root.addView(scroll,position(-1,-1,Gravity.FILL,55,132,55,24));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list,new ScrollView.LayoutParams(-1,-2));
        PackageManager pm=getPackageManager();
        Map<String,ResolveInfo> found=new LinkedHashMap<>();
        for(String category:new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER,Intent.CATEGORY_LAUNCHER}) {
            Intent query=new Intent(Intent.ACTION_MAIN);query.addCategory(category);
            try {
                for(ResolveInfo info:pm.queryIntentActivities(query,0)) {
                    if(info.activityInfo==null)continue;
                    String pkg=info.activityInfo.packageName;
                    if(!getPackageName().equals(pkg) && !found.containsKey(pkg)) found.put(pkg,info);
                }
            }catch(Exception ignored){}
        }
        ArrayList<ResolveInfo> entries=new ArrayList<>(found.values());
        Collections.sort(entries,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
        if(entries.isEmpty()){
            TextView empty=Ui.label(this,"No other installed apps were found.",19,Color.WHITE,false);
            list.addView(empty,new LinearLayout.LayoutParams(-1,Ui.dp(this,70)));
        }
        View first=null;
        for(ResolveInfo info:entries){
            String pkg=info.activityInfo.packageName;
            LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
            row.setOrientation(LinearLayout.HORIZONTAL);Ui.padding(row,this,14,8,14,8);
            row.setFocusable(true);row.setClickable(true);
            row.setBackground(Ui.bgBorder(0xA334285A,9,0x6CA58DC2,1,this));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,66));rp.bottomMargin=Ui.dp(this,6);list.addView(row,rp);
            ImageView icon=new ImageView(this);
            try{icon.setImageDrawable(info.loadIcon(pm));}catch(Exception ignored){}
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,48));ip.rightMargin=Ui.dp(this,18);
            row.addView(icon,ip);
            TextView name=Ui.label(this,String.valueOf(info.loadLabel(pm)),19,Color.WHITE,false);
            row.addView(name,new LinearLayout.LayoutParams(-1,-1));
            row.setOnClickListener(v->{
                try {
                    Intent launch=pm.getLeanbackLaunchIntentForPackage(pkg);
                    if(launch==null)launch=pm.getLaunchIntentForPackage(pkg);
                    if(launch==null){launch=new Intent(Intent.ACTION_MAIN);launch.addCategory(Intent.CATEGORY_LAUNCHER);
                        launch.setClassName(pkg,info.activityInfo.name);}
                    startActivity(launch);
                }catch(Exception e){Toast.makeText(this,"Unable to open this app",Toast.LENGTH_SHORT).show();}
            });
            row.setOnFocusChangeListener((v,f)->{
                row.setBackground(Ui.bgBorder(f?0xC1654AAC:0xA334285A,9,f?Color.WHITE:0x6CA58DC2,f?3:1,this));
                row.animate().scaleX(f?1.006f:1f).scaleY(f?1.006f:1f).setDuration(100).start();
            });
            if(first==null)first=row;
        }
        setContentView(root);
        if(first!=null)first.requestFocus();
    }
}
