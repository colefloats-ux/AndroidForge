package com.androidtv.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.widget.Toast;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;

public final class AppCatalog {
    private AppCatalog() {}
    private static final ConcurrentHashMap<String,Intent> READY=new ConcurrentHashMap<>();
    /** Warm known installed app launch intents in the background. Never blocks drawing Home. */
    public static void prewarm(android.content.Context context){
        android.content.Context app=context.getApplicationContext();
        new Thread(()->{
            PackageManager pm=app.getPackageManager();
            for(Channel channel:CHANNELS){
                if(READY.containsKey(channel.title))continue;
                for(String pkg:channel.packages){
                    try {
                        Intent intent=pm.getLeanbackLaunchIntentForPackage(pkg);
                        if(intent==null)intent=pm.getLaunchIntentForPackage(pkg);
                        if(intent!=null){READY.put(channel.title,intent);break;}
                    }catch(Exception ignored){}
                }
            }
        },"AndroidTV-app-prefetch").start();
    }
    public static final class Channel {
        public final String title,mark,search;
        public final int color, logoColor;
        public final String[] packages;
        Channel(String title,String mark,String search,int color,int logoColor,String... packages) {
            this.title=title;this.mark=mark;this.search=search;this.color=color;this.logoColor=logoColor;this.packages=packages;
        }
    }
    public static final Channel[] CHANNELS={
        new Channel("Live TV","▣  Live TV","directv",Color.rgb(100,61,169),Color.WHITE,"com.att.tv"),
        new Channel("Stremio","Stremio","stremio",Color.rgb(56,47,118),Color.WHITE,"com.stremio.one"),
        new Channel("Hulu","hulu","hulu",Color.rgb(10,21,23),Color.rgb(42,220,132),"com.hulu.livingroomplus","com.hulu.plus"),
        new Channel("Disney+","Disney+","disney",Color.rgb(19,40,104),Color.WHITE,"com.disney.disneyplus"),
        new Channel("HBO Max","HBO max","max",Color.rgb(34,24,77),Color.WHITE,"com.wbd.stream","com.hbo.hbonow","com.hbo.hbonow2"),
        new Channel("Peacock","peacock","peacock",Color.rgb(22,22,33),Color.WHITE,"com.peacocktv.peacockandroid"),
        new Channel("Prime Video","prime video","prime video",Color.rgb(18,53,100),Color.WHITE,"com.amazon.amazonvideo.livingroom","com.amazon.avod.thirdpartyclient"),
        new Channel("Paramount+","Paramount+","paramount",Color.rgb(19,57,125),Color.WHITE,"com.cbs.ott","com.cbs.app")
    };

    public static void open(Activity a,Channel channel) {
        // Most launches use a prepared Intent, avoiding package-manager lookups after OK.
        Intent prepared=READY.get(channel.title);
        if(prepared!=null) {
            try{a.startActivity(new Intent(prepared));return;}
            catch(Exception ignored){READY.remove(channel.title);}
        }
        PackageManager pm=a.getPackageManager();
        for(String pkg:channel.packages) {
            Intent launch = pm.getLeanbackLaunchIntentForPackage(pkg);
            if(launch==null)launch=pm.getLaunchIntentForPackage(pkg);
            if(launch!=null) {try {READY.put(channel.title,new Intent(launch));a.startActivity(launch);return;}catch(Exception ignored) {}}
        }
        // Find branded applications even if their package identifiers have changed.
        Intent lean=new Intent(Intent.ACTION_MAIN);lean.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        if (openMatching(a,pm,lean,channel.search))return;
        Intent normal=new Intent(Intent.ACTION_MAIN);normal.addCategory(Intent.CATEGORY_LAUNCHER);
        if (openMatching(a,pm,normal,channel.search))return;
        new AlertDialog.Builder(a)
            .setTitle(channel.title+" isn't installed")
            .setMessage("Install "+(channel.title.equals("Live TV")?"DIRECTV":"the "+channel.title+" app")+" from your TV's app store. Once installed, this tile will launch it automatically.")
            .setPositiveButton("Open app store",(d,w)->openStore(a,channel.packages[0]))
            .setNegativeButton("Cancel",null).show();
    }
    private static boolean openMatching(Activity a,PackageManager pm,Intent query,String needle) {
        try {
            List<ResolveInfo> found=pm.queryIntentActivities(query,0);
            for(ResolveInfo info:found) {
                if(info.activityInfo==null)continue;
                String label=String.valueOf(info.loadLabel(pm)).toLowerCase(Locale.US);
                String pkg=info.activityInfo.packageName;
                String normalized=(label+" "+pkg).toLowerCase(Locale.US);
                if (normalized.contains(needle.toLowerCase(Locale.US))) {
                    Intent launch=new Intent(Intent.ACTION_MAIN);
                    launch.addCategory(query.hasCategory(Intent.CATEGORY_LEANBACK_LAUNCHER) ? Intent.CATEGORY_LEANBACK_LAUNCHER : Intent.CATEGORY_LAUNCHER);
                    launch.setClassName(pkg,info.activityInfo.name);
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try{a.startActivity(launch);return true;}catch(Exception ignored){}
                }
            }
        }catch(Exception ignored){}
        return false;
    }
    private static void openStore(Activity a,String pkg) {
        try{a.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id="+pkg)));}
        catch(ActivityNotFoundException e) {
            try{a.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id="+pkg)));}
            catch(Exception ignored){Toast.makeText(a,"Open your TV app store to install this app.",Toast.LENGTH_LONG).show();}
        }
    }
}
