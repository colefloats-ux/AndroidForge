package com.androidtv.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;

/** Requests the public Android Home role. Never attempts to escalate system privileges. */
public final class HomeRole {
    private HomeRole() {}
    public static final int REQUEST_CODE = 71;
    public static final String ADB_COMMAND = "adb shell cmd package set-home-activity com.androidtv.launcher/.MainActivity";

    public static boolean isDefault(Context context) {
        if(Build.VERSION.SDK_INT >= 29) {
            RoleManager rm=context.getSystemService(RoleManager.class);
            if(rm!=null && rm.isRoleAvailable(RoleManager.ROLE_HOME))
                return rm.isRoleHeld(RoleManager.ROLE_HOME);
        }
        try {
            Intent home=new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            ResolveInfo ri=context.getPackageManager().resolveActivity(home,PackageManager.MATCH_DEFAULT_ONLY);
            return ri!=null && ri.activityInfo!=null && context.getPackageName().equals(ri.activityInfo.packageName);
        } catch(Exception ignored){return false;}
    }

    public static void request(Activity a) {
        if(isDefault(a)) {
            Toast.makeText(a,"AndroidTV is already the default Home app.",Toast.LENGTH_SHORT).show();return;
        }
        if(Build.VERSION.SDK_INT >= 29) {
            try {
                RoleManager rm=a.getSystemService(RoleManager.class);
                if(rm!=null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    a.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), REQUEST_CODE);
                    return;
                }
            } catch(Exception ignored) { /* Use public Settings fallback. */ }
        }
        try {a.startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));}
        catch(Exception e) { showRestrictedHelp(a); }
    }

    public static void showRestrictedHelp(Activity a) {
        new AlertDialog.Builder(a)
            .setTitle("Default launcher setup")
            .setMessage("AndroidTV is registered as a Home app. First try Settings > Apps > Default apps > Home. " +
              "Some TV manufacturers hide or lock that option. An ADB-authorized device can try:\n\n" + ADB_COMMAND +
              "\n\nThis requires user-approved debugging access. It may not work on manufacturer-locked TVs. " +
              "Do not disable the original TV launcher without a tested recovery method.")
            .setPositiveButton("Copy ADB command",(d,w)->{
                ClipboardManager cm=(ClipboardManager)a.getSystemService(Context.CLIPBOARD_SERVICE);
                if(cm!=null)cm.setPrimaryClip(ClipData.newPlainText("AndroidTV launcher",ADB_COMMAND));
                Toast.makeText(a,"Command copied",Toast.LENGTH_SHORT).show();
            })
            .setNeutralButton("System settings",(d,w)->{
                try{a.startActivity(new Intent(Settings.ACTION_SETTINGS));}
                catch(Exception e){Toast.makeText(a,"Settings not available",Toast.LENGTH_SHORT).show();}
            })
            .setNegativeButton("Close",null).show();
    }
}
