package com.androidtv.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int VOICE_REQUEST=30;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final SimpleDateFormat timeFormat=new SimpleDateFormat("h:mm a",Locale.US);
    private final Runnable clockUpdater=new Runnable(){
        @Override public void run(){if(clock!=null)clock.setText(timeFormat.format(new Date()));handler.postDelayed(this,30000);}
    };
    private FrameLayout root;
    private ImageView wallpaper;
    private ThemeEffectsView ambient;
    private LaunchTransitionView transition;
    private TextView clock;
    private View firstChannel;
    private GridLayout tileGrid;
    private final Map<Integer,View> tileViews=new HashMap<>();
    private ArrayList<Integer> tileOrder=new ArrayList<>();
    private ArrayList<Integer> moveOriginal;
    private int movingId=-1;
    private int tileWidthDp=175,tileHeightDp=112,tileSpacingDp=9;
    private TextView moveHint;
    private TextView verseText;
    private TextView verseReference;
    private long suppressClickUntil=0L;

    private int currentTheme=4;
    private boolean currentEffects=true;
    private int currentIntensity=1;
    private int shownWallpaper=-1;
    private long lastLaunchTap=0L;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        immersive();
        createHome();
        showSetupOnFirstOpen();
    }
    /** One-time, remote-navigable shortcut for choosing a default Home app. */
    private void showSetupOnFirstOpen(){
        if(HomeRole.isDefault(this))return;
        android.content.SharedPreferences prefs=ThemeConfig.prefs(this);
        if(prefs.getBoolean("home_intro_shown",false))return;
        prefs.edit().putBoolean("home_intro_shown",true).apply();
        root.post(()->new AlertDialog.Builder(this)
            .setTitle("Use AndroidTV as your Home screen?")
            .setMessage("To open AndroidTV when you press the TV Home button, choose it as your default Home app. Some manufacturers restrict this setting.")
            .setPositiveButton("Set as default",(d,w)->HomeRole.request(this))
            .setNegativeButton("Later",null).show());
    }
    private void immersive(){
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
    @Override public void onConfigurationChanged(Configuration newConfig){super.onConfigurationChanged(newConfig);createHome();}
    private FrameLayout.LayoutParams pos(int width,int height,int gravity,int left,int top,int right,int bottom){
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(width<0?width:Ui.dp(this,width),height<0?height:Ui.dp(this,height),gravity);
        p.setMargins(Ui.dp(this,left),Ui.dp(this,top),Ui.dp(this,right),Ui.dp(this,bottom));return p;
    }
    private void createHome(){
        float density=getResources().getDisplayMetrics().density;
        int physicalW=Math.round(getResources().getDisplayMetrics().widthPixels/density);
        int physicalH=Math.round(getResources().getDisplayMetrics().heightPixels/density);
        // Always lay out controls on a centered 16:9 canvas. Only wallpaper uses the full screen.
        // A wide or oddly reported TV resolution must never widen tiles or their logos.
        final int screenW=Math.min(physicalW,Math.round(physicalH*16f/9f));
        final int screenH=Math.min(physicalH,Math.round(physicalW*9f/16f));
        final int insetX=(physicalW-screenW)/2;
        final int insetY=(physicalH-screenH)/2;
        root=new FrameLayout(this);root.setBackgroundColor(Color.rgb(38,29,69));
        root.setFocusableInTouchMode(true);
        wallpaper=new ImageView(this);wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(wallpaper,new FrameLayout.LayoutParams(-1,-1));
        View veil=new View(this);
        GradientDrawable veilGradient=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0x8D16122E,0x5821163C,0x34151230,0x221A163A});
        veil.setBackground(veilGradient);root.addView(veil,new FrameLayout.LayoutParams(-1,-1));
        ambient=new ThemeEffectsView(this);root.addView(ambient,new FrameLayout.LayoutParams(-1,-1));

        TextView title=Ui.label(this,"AndroidTV",30,Color.WHITE,true);title.setLetterSpacing(-.035f);
        root.addView(title,pos(300,48,Gravity.TOP|Gravity.LEFT,insetX+Math.round(screenW*.085f),insetY+Math.round(screenH*.06f),0,0));
        clock=Ui.label(this,"",20,Color.WHITE,true);clock.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        root.addView(clock,pos(150,38,Gravity.TOP|Gravity.RIGHT,0,insetY+Math.round(screenH*.066f),insetX+Math.round(screenW*.055f),0));

        // Geometry measured from the user-approved compact 16:9 Roku-style reference.
        int sidebarTop=Math.max(100,Math.round(screenH*.258f));
        LinearLayout sidebar=new LinearLayout(this);sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setFocusable(false);
        root.addView(sidebar,pos(Math.round(screenW*.24f),-2,Gravity.TOP|Gravity.LEFT,
            insetX+Math.round(screenW*.062f),insetY+sidebarTop,0,0));
        makeSidebarItem(sidebar,"", "Home",()->{if(firstChannel!=null)firstChannel.requestFocus();},true);
        makeSidebarItem(sidebar,"", "Search",this::promptSearch,false);
        makeSidebarItem(sidebar,"", "Settings",()->startActivity(new Intent(this,SettingsActivity.class)),false);

        final int left=insetX+Math.round(screenW*.342f);
        final int gridTop=insetY+Math.max(100,Math.round(screenH*.255f));
        final int spacing=Math.max(6,Math.round(screenW*.008f));
        final int available=Math.max(0,insetX+screenW-left-Math.round(screenW*.035f));
        final int tileW=Math.max(70,Math.min(Math.round(screenW*.1365f),(available-spacing*4)/4));
        // A single immutable media ratio: 450x288. Never squeeze images to fit another ratio.
        final int tileH=Math.max(46,Math.round(tileW*288f/450f));
        tileWidthDp=tileW;tileHeightDp=tileH;tileSpacingDp=spacing;
        tileGrid=new GridLayout(this);tileGrid.setColumnCount(4);tileGrid.setRowCount(2);
        tileOrder=HomeTiles.load(this);
        renderTiles(tileW,tileH,spacing);
        root.addView(tileGrid,pos(-2,-2,Gravity.TOP|Gravity.LEFT,left,gridTop,0,0));
        TextView more=Ui.label(this,"›",37,0xC1FFFFFF,false);
        more.setGravity(Gravity.CENTER);
        more.setFocusable(true);more.setClickable(true);
        more.setContentDescription("Show all installed apps");
        more.setOnClickListener(v->startActivity(new Intent(this,AllAppsActivity.class)));
        more.setOnFocusChangeListener((v,f)->{
            more.setTextColor(f?Color.WHITE:0xC1FFFFFF);
            more.setBackground(f?Ui.bgBorder(0xA35E4196,10,Color.WHITE,2,this):null);
        });
        int arrowLeft=left+(tileW+spacing)*4+8;
        if(arrowLeft<insetX+screenW-40)root.addView(more,pos(34,64,Gravity.TOP|Gravity.LEFT,arrowLeft,insetY+Math.max(100,Math.round(screenH*.255f))+tileH/2+7,0,0));

        moveHint=Ui.label(this,"Use arrow keys to move  •  OK to save  •  Back to cancel",15,Color.WHITE,true);
        moveHint.setGravity(Gravity.CENTER);
        moveHint.setBackground(Ui.bgBorder(0xE23A205F,12,0xFFFFD37A,2,this));
        moveHint.setVisibility(View.GONE);
        root.addView(moveHint,pos(Math.round(screenW*.63f),43,Gravity.TOP|Gravity.LEFT,
            insetX+Math.round(screenW*.27f),insetY+Math.round(screenH*.56f),0,0));

        // The user-approved golden, high-contrast Bible verse replaces the previous Gemini pill.
        int verseW=Math.round(screenW*.59f);
        int verseH=Math.max(105,Math.round(screenH*.19f));
        LinearLayout gold=new LinearLayout(this);
        gold.setOrientation(LinearLayout.VERTICAL);
        gold.setGravity(Gravity.CENTER);
        Ui.padding(gold,this,23,6,23,7);
        android.graphics.drawable.GradientDrawable goldBackground=new android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0xFFFFE29A,0xFFFFC94F,0xFFE8A42C});
        goldBackground.setCornerRadius(Ui.dp(this,23));
        goldBackground.setStroke(Ui.dp(this,2),0xFFFFEEB6);
        gold.setBackground(goldBackground);
        gold.setElevation(Ui.dp(this,8));
        gold.setFocusable(true);gold.setClickable(true);
        gold.setContentDescription("Verse of the Day from VerseOfTheDay.com. Press OK to read the full verse.");
        TextView verseHeading=Ui.label(this,"VERSE OF THE DAY",14,0xFF16120C,true);
        verseHeading.setGravity(Gravity.CENTER);verseHeading.setLetterSpacing(.10f);
        gold.addView(verseHeading,new LinearLayout.LayoutParams(-1,Ui.dp(this,23)));
        verseText=Ui.label(this,"Loading today's verse…",21,0xFF16120C,true);
        verseText.setTypeface(Typeface.create("serif",Typeface.BOLD));
        verseText.setGravity(Gravity.CENTER);verseText.setMaxLines(4);
        verseText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        gold.addView(verseText,new LinearLayout.LayoutParams(-1,0,1));
        verseReference=Ui.label(this,"VerseOfTheDay.com",16,0xFF22190E,false);
        verseReference.setTypeface(Typeface.create("serif",Typeface.NORMAL));
        verseReference.setGravity(Gravity.CENTER);
        gold.addView(verseReference,new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));
        gold.setOnClickListener(v->showFullVerse());
        gold.setOnFocusChangeListener((v,focus)->{
            goldBackground.setStroke(Ui.dp(this,focus?4:2),focus?Color.WHITE:0xFFFFEEB6);
        });
        root.addView(gold,pos(verseW,verseH,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL,0,0,0,
            insetY+Math.round(screenH*.044f)));

        transition=new LaunchTransitionView(this);
        root.addView(transition,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        refreshTheme();
        AppCatalog.prewarm(this);
        if(firstChannel!=null)firstChannel.requestFocus();
        refreshVerse();
    }
    private void makeSidebarItem(LinearLayout parent,String icon,String text,Runnable action,boolean active){
        LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);
        line.setOrientation(LinearLayout.HORIZONTAL);Ui.padding(line,this,12,0,6,0);
        line.setFocusable(true);line.setClickable(true);
        line.setBackground(Ui.bg(active?0x85573F9F:0x00000000,8,this));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,Ui.dp(this,38));lp.bottomMargin=Ui.dp(this,5);
        parent.addView(line,lp);
        TextView label=Ui.label(this,text,18,Color.WHITE,active);
        LinearLayout.LayoutParams labelParams=new LinearLayout.LayoutParams(-1,-1);
        labelParams.leftMargin=Ui.dp(this,9);line.addView(label,labelParams);
        line.setOnClickListener(v->action.run());
        line.setOnFocusChangeListener((v,has)->line.setBackground(Ui.bgBorder(has?0xD16A4AA7:(active?0x85573F9F:0x00000000),8,has?Color.WHITE:Color.TRANSPARENT,has?2:0,this)));
    }
    private int tileArt(int index){
        switch(index){
            case 0:return R.drawable.tile_live;
            case 1:return R.drawable.tile_stremio;
            case 2:return R.drawable.tile_hulu;
            case 3:return R.drawable.tile_disney;
            case 4:return R.drawable.tile_max;
            case 5:return R.drawable.tile_peacock;
            case 6:return R.drawable.tile_prime;
            default:return R.drawable.tile_paramount;
        }
    }
    private View makeChannel(AppCatalog.Channel channel,int tileW,int tileH,Runnable click){
        FrameLayout tile=new FrameLayout(this);
        tile.setFocusable(true);tile.setClickable(true);
        tile.setContentDescription(channel.title+" channel");
        tile.setBackground(Ui.bg(channel.color,7,this));
        tile.setClipToOutline(true);
        tile.setElevation(Ui.dp(this,2));
        int i=java.util.Arrays.asList(AppCatalog.CHANNELS).indexOf(channel);
        ImageView artwork=new ImageView(this);
        artwork.setScaleType(ImageView.ScaleType.FIT_CENTER); // preserve the logo's aspect ratio
        artwork.setImageResource(tileArt(i));
        artwork.setFocusable(false);
        tile.addView(artwork,new FrameLayout.LayoutParams(-1,-1));
        tile.setForeground(Ui.bgBorder(Color.TRANSPARENT,7,0x00000000,0,this));
        tile.setOnClickListener(v->{
            if(SystemClock.uptimeMillis()<suppressClickUntil)return;
            if(movingId>=0){finishMoving(true);return;}
            click.run();
        });
        tile.setOnFocusChangeListener((v,focused)->{
            tile.setForeground(Ui.bgBorder(Color.TRANSPARENT,7,focused?0xFFFFFFFF:0x00000000,focused?2:0,this));
            tile.setElevation(Ui.dp(this,focused?9:2));
            tile.animate().scaleX(focused?1.018f:1).scaleY(focused?1.018f:1).setDuration(110).start();
        });
        return tile;
    }
    /** Add independent app tile views. Focus border is drawn by Android, never baked into logos. */
    private void renderTiles(int tileW,int tileH,int spacing){
        tileGrid.removeAllViews();tileViews.clear();firstChannel=null;
        for(int displayIndex=0;displayIndex<tileOrder.size();displayIndex++){
            int id=tileOrder.get(displayIndex);
            View tile=makeChannel(AppCatalog.CHANNELS[id],tileW,tileH,()->openChannel(id));
            configureLongPress(tile,id);
            GridLayout.LayoutParams lp=new GridLayout.LayoutParams(
                GridLayout.spec(displayIndex/4),GridLayout.spec(displayIndex%4));
            lp.width=Ui.dp(this,tileW);lp.height=Ui.dp(this,tileH);
            lp.setMargins(Ui.dp(this,spacing/2),Ui.dp(this,spacing/2),
                Ui.dp(this,spacing/2),Ui.dp(this,spacing/2));
            tileGrid.addView(tile,lp);tileViews.put(id,tile);
            if(firstChannel==null)firstChannel=tile;
        }
    }
    /** A true three-second remote-center press (normal short OK still opens the app). */
    private void configureLongPress(View tile,int id){
        final Runnable[] delayed={null};
        final boolean[] fired={false};
        tile.setOnKeyListener((v,key,event)->{
            boolean select=key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER||
                key==KeyEvent.KEYCODE_NUMPAD_ENTER||key==KeyEvent.KEYCODE_BUTTON_A;
            if(movingId==id){
                if(event.getAction()==KeyEvent.ACTION_DOWN && event.getRepeatCount()==0){
                    if(key==KeyEvent.KEYCODE_DPAD_LEFT || key==KeyEvent.KEYCODE_DPAD_RIGHT ||
                       key==KeyEvent.KEYCODE_DPAD_UP || key==KeyEvent.KEYCODE_DPAD_DOWN){
                        int from=tileOrder.indexOf(id);
                        int next=from+(key==KeyEvent.KEYCODE_DPAD_LEFT?-1:
                                key==KeyEvent.KEYCODE_DPAD_RIGHT?1:
                                key==KeyEvent.KEYCODE_DPAD_UP?-4:4);
                        if(next>=0&&next<tileOrder.size()){
                            Collections.swap(tileOrder,from,next);
                            reflowTiles();
                        }
                        return true;
                    }
                    if(select){finishMoving(true);return true;}
                    if(key==KeyEvent.KEYCODE_BACK){finishMoving(false);return true;}
                }
                return true;
            }
            if(!select)return false;
            if(event.getAction()==KeyEvent.ACTION_DOWN && event.getRepeatCount()==0){
                fired[0]=false;
                delayed[0]=()->{
                    fired[0]=true;
                    suppressClickUntil=SystemClock.uptimeMillis()+500L;
                    showTileMenu(tile,id);
                };
                handler.postDelayed(delayed[0],3000L);
            }else if(event.getAction()==KeyEvent.ACTION_UP){
                if(delayed[0]!=null)handler.removeCallbacks(delayed[0]);
                delayed[0]=null;
                if(fired[0]){fired[0]=false;return true;}
            }
            return false;
        });
        tile.setOnFocusChangeListener((v,focused)->{
            tile.setForeground(Ui.bgBorder(Color.TRANSPARENT,7,
                movingId==id?0xFFFFD27A:focused?Color.WHITE:0x00000000,
                movingId==id?3:focused?2:0,this));
            tile.setElevation(Ui.dp(this,focused?9:2));
            tile.animate().scaleX(focused?1.018f:1).scaleY(focused?1.018f:1).setDuration(110).start();
            if(!focused && delayed[0]!=null){handler.removeCallbacks(delayed[0]);delayed[0]=null;}
        });
    }
    private void showTileMenu(View tile,int id){
        if(isFinishing()||movingId>=0)return;
        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        Ui.padding(content,this,11,10,11,10);
        content.setBackground(Ui.bgBorder(0xF334204B,15,0xFFC6A4F1,2,this));
        TextView heading=Ui.label(this,AppCatalog.CHANNELS[id].title,19,Color.WHITE,true);
        Ui.padding(heading,this,8,0,8,0);
        content.addView(heading,new LinearLayout.LayoutParams(-1,Ui.dp(this,37)));
        PopupWindow window=new PopupWindow(content,Ui.dp(this,245),Ui.dp(this,209),true);
        window.setBackgroundDrawable(Ui.bgBorder(0xFF34204B,15,0xFFC6A4F1,2,this));
        window.setOutsideTouchable(true);window.setElevation(Ui.dp(this,16));
        addMenuRow(content,"✥   Move",()->{window.dismiss();startMoving(id);},true);
        addMenuRow(content,"▢   Remove from Home",()->{
            window.dismiss();
            new AlertDialog.Builder(this).setTitle("Remove " + AppCatalog.CHANNELS[id].title + "?")
                .setMessage("This hides the tile from Home. It will not uninstall the app. Restore your tiles in Settings.")
                .setPositiveButton("Remove",(d,w)->{
                    tileOrder.remove(Integer.valueOf(id));HomeTiles.save(this,tileOrder);
                    reflowTiles();if(firstChannel!=null)firstChannel.requestFocus();
                }).setNegativeButton("Cancel",null).show();
        },false);
        addMenuRow(content,"×   Cancel",window::dismiss,false);
        int[] loc=new int[2];tile.getLocationOnScreen(loc);
        int w=getResources().getDisplayMetrics().widthPixels;
        int h=getResources().getDisplayMetrics().heightPixels;
        int x=Math.min(Math.max(0,loc[0]+tile.getWidth()-Ui.dp(this,6)),w-Ui.dp(this,255));
        int y=Math.max(Ui.dp(this,35),Math.min(loc[1]-Ui.dp(this,50),h-Ui.dp(this,220)));
        window.showAtLocation(root,Gravity.TOP|Gravity.LEFT,x,y);
        content.getChildAt(1).requestFocus();
    }
    private void addMenuRow(LinearLayout parent,String title,Runnable action,boolean initial){
        TextView row=Ui.label(this,title,17,Color.WHITE,false);
        Ui.padding(row,this,13,0,0,0);
        row.setFocusable(true);row.setClickable(true);
        row.setBackground(Ui.bg(initial?0xFFB5A0F1:Color.TRANSPARENT,9,this));
        row.setTextColor(initial?0xFF1B1031:Color.WHITE);
        row.setOnFocusChangeListener((v,f)->{
            row.setBackground(Ui.bg(f?0xFFE1D5FF:0x00000000,9,this));
            row.setTextColor(f?0xFF1B1031:Color.WHITE);
        });
        row.setOnClickListener(v->action.run());
        parent.addView(row,new LinearLayout.LayoutParams(-1,Ui.dp(this,49)));
    }
    private void startMoving(int id){
        movingId=id;
        moveOriginal=new ArrayList<>(tileOrder);
        moveHint.setVisibility(View.VISIBLE);
        View v=tileViews.get(id);if(v!=null)v.requestFocus();
    }
    private void finishMoving(boolean save){
        if(movingId<0)return;
        int id=movingId;
        if(save)HomeTiles.save(this,tileOrder);
        else if(moveOriginal!=null){tileOrder=new ArrayList<>(moveOriginal);}
        movingId=-1;moveOriginal=null;
        moveHint.setVisibility(View.GONE);reflowTiles();
        View v=tileViews.get(id);if(v!=null)v.requestFocus();
    }
    private void reflowTiles(){
        if(tileGrid==null)return;
        renderTiles(tileWidthDp,tileHeightDp,tileSpacingDp);
        if(movingId>=0){View current=tileViews.get(movingId);if(current!=null)current.requestFocus();}
    }
    private void refreshVerse(){
        if(verseText==null)return;
        VerseOfDay.load(this,verse->{
            if(isFinishing()||verseText==null)return;
            verseText.setText(verse.text);
            int len=verse.text.length();
            verseText.setTextSize(len>220?15:len>150?17:len>95?19:23);
            verseReference.setText(verse.reference+(verse.translation.isEmpty()?"":"  •  "+verse.translation));
        });
    }
    private void showFullVerse(){
        VerseOfDay.Verse verse=VerseOfDay.cached(this);
        if(verse==null){
            new AlertDialog.Builder(this).setTitle("Verse of the Day unavailable")
                .setMessage("The TV hasn't received the publisher's verse yet. Check the internet connection or read it on the website.")
                .setPositiveButton("Visit website",(d,w)->{
                    try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.verseoftheday.com/")));}
                    catch(Exception ignored){Toast.makeText(this,"A web browser is required.",Toast.LENGTH_SHORT).show();}
                }).setNeutralButton("Try again",(d,w)->refreshVerse())
                .setNegativeButton("Close",null).show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("Verse of the Day  —  "+verse.reference)
            .setMessage(verse.text+"\n\nSource: verseoftheday.com")
            .setPositiveButton("Read on website",(d,w)->{
                try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.verseoftheday.com/")));}
                catch(Exception ignored){Toast.makeText(this,"A web browser is required.",Toast.LENGTH_SHORT).show();}
            }).setNegativeButton("Close",null).show();
    }

    private void refreshTheme(){
        currentTheme=ThemeConfig.themeIndex(this);
        currentEffects=ThemeConfig.effects(this);
        currentIntensity=ThemeConfig.intensity(this);
        if(shownWallpaper!=currentTheme){
            shownWallpaper=currentTheme;
            WallpaperCache.set(wallpaper,ThemeConfig.wallpaper(currentTheme));
        }
        ambient.setScene(currentTheme,currentEffects?currentIntensity:0);
    }
    private void openChannel(int index){
        long now=SystemClock.uptimeMillis();
        if(now-lastLaunchTap<230L)return; // Ignore duplicate OK repeats, never delay first press.
        lastLaunchTap=now;
        AppCatalog.Channel channel=AppCatalog.CHANNELS[index];
        transition.launch(currentTheme,currentEffects && currentIntensity>0,ThemeConfig.instant(this),
            ()->AppCatalog.open(this,channel));
    }
    private void promptSearch(){
        EditText input=new EditText(this);input.setSingleLine(true);input.setTextSize(18);
        input.setInputType(InputType.TYPE_CLASS_TEXT);input.setHint("Movies, apps, questions…");
        Ui.padding(input,this,20,8,20,8);
        new AlertDialog.Builder(this).setTitle("Search apps and ask Gemini")
                .setView(input)
                .setPositiveButton("Search",(d,w)->universalSearch(input.getText().toString()))
                .setNeutralButton("Gemini",(d,w)->openGemini(input.getText().toString()))
                .setNegativeButton("Cancel",null).show();
    }
    /** Searches installed applications locally. Gemini and a web search remain selectable for other queries. */
    private void universalSearch(String phrase){
        final String query=phrase.trim();
        if(query.isEmpty()){promptSearch();return;}
        final java.util.ArrayList<String> labels=new java.util.ArrayList<>();
        final java.util.ArrayList<Runnable> actions=new java.util.ArrayList<>();
        String lowered=query.toLowerCase(Locale.US);
        for(AppCatalog.Channel channel:AppCatalog.CHANNELS){
            if(channel.title.toLowerCase(Locale.US).contains(lowered) ||
               channel.search.toLowerCase(Locale.US).contains(lowered) ||
               (channel.title.equals("Live TV") && (lowered.contains("tv") || lowered.contains("directv")))){
                labels.add("Open " + channel.title + (channel.title.equals("Live TV")?" (DIRECTV)":""));
                actions.add(()->AppCatalog.open(this,channel));
            }
        }
        // Search all additional installed apps shown in All Apps, not just the eight home tiles.
        android.content.pm.PackageManager pm=getPackageManager();
        java.util.HashSet<String> seen=new java.util.HashSet<>();
        for(String category:new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER,Intent.CATEGORY_LAUNCHER}) {
            Intent intent=new Intent(Intent.ACTION_MAIN);intent.addCategory(category);
            try{
                for(android.content.pm.ResolveInfo info:pm.queryIntentActivities(intent,0)) {
                    if(info.activityInfo==null)continue;
                    String pkg=info.activityInfo.packageName;
                    if(pkg.equals(getPackageName()) || !seen.add(pkg))continue;
                    String name=String.valueOf(info.loadLabel(pm));
                    if(!name.toLowerCase(Locale.US).contains(lowered))continue;
                    // Avoid duplicate hits when a fixed channel already represents this application.
                    boolean homeChannel=false;
                    for(AppCatalog.Channel channel:AppCatalog.CHANNELS)
                        for(String known:channel.packages)if(pkg.equals(known))homeChannel=true;
                    if(homeChannel)continue;
                    labels.add("Open " + name);
                    actions.add(()->{
                        try{
                            Intent launch=pm.getLeanbackLaunchIntentForPackage(pkg);
                            if(launch==null)launch=pm.getLaunchIntentForPackage(pkg);
                            if(launch!=null)startActivity(launch);
                        }catch(Exception e){Toast.makeText(this,"Unable to open " + name,Toast.LENGTH_SHORT).show();}
                    });
                }
            }catch(Exception ignored){}
        }
        labels.add("Ask Gemini (opens browser)");actions.add(()->openGemini(query));
        labels.add("Search the web");actions.add(()->tvSearch(query));
        new AlertDialog.Builder(this).setTitle("Results for “"+query+"”")
            .setItems(labels.toArray(new String[0]),(d,index)->actions.get(index).run())
            .setNegativeButton("Cancel",null).show();
    }
    private void voiceSearch(){
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT,"What would you like to find?");
        try{startActivityForResult(i,VOICE_REQUEST);}catch(ActivityNotFoundException e){
            Toast.makeText(this,"Voice recognition isn't available on this TV. Use OK to type.",Toast.LENGTH_LONG).show();promptSearch();
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==VOICE_REQUEST && result==RESULT_OK && data!=null){
            ArrayList<String> words=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(words!=null && !words.isEmpty())universalSearch(words.get(0));
        }
    }
    private void openGemini(String query){
        if(!query.trim().isEmpty()){
            // Public Gemini web does not provide a supported Android TV deep link for directly submitting prompts.
            ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            if(clipboard!=null)clipboard.setPrimaryClip(ClipData.newPlainText("Gemini prompt",query.trim()));
            Toast.makeText(this,"Prompt copied. Paste into Gemini to ask.",Toast.LENGTH_LONG).show();
        }
        try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://gemini.google.com/app")));}
        catch(Exception e){Toast.makeText(this,"Install a browser to open Gemini, or select TV search.",Toast.LENGTH_LONG).show();}
    }
    private void tvSearch(String query){
        if(query.trim().isEmpty()){promptSearch();return;}
        Intent i=new Intent(Intent.ACTION_WEB_SEARCH);i.putExtra(SearchManager.QUERY,query.trim());
        try{startActivity(i);}catch(ActivityNotFoundException e){
            try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(query.trim()))));}
            catch(Exception ignored){Toast.makeText(this,"No search app or browser is installed.",Toast.LENGTH_LONG).show();}
        }
    }
    @Override protected void onResume(){super.onResume();immersive();if(wallpaper!=null){refreshTheme();ambient.start();refreshVerse();}handler.removeCallbacks(clockUpdater);clockUpdater.run();}
    @Override protected void onPause(){
        if(ambient!=null)ambient.stop();
        if(transition!=null)transition.stop();
        handler.removeCallbacks(clockUpdater);
        super.onPause();
    }
    @Override protected void onDestroy(){handler.removeCallbacks(clockUpdater);super.onDestroy();}
    @Override public void onBackPressed(){
        if(movingId>=0){finishMoving(false);return;}
        if(firstChannel!=null)firstChannel.requestFocus();else super.onBackPressed();
    }
}
