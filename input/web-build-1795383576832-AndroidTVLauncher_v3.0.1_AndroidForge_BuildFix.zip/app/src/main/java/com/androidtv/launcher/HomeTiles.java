package com.androidtv.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/** Stable, device-local order for the eight curated Home tiles. Hiding is not uninstalling. */
public final class HomeTiles {
    private static final String KEY="home_tile_order_v3";
    private HomeTiles() {}
    public static ArrayList<Integer> load(Context context) {
        SharedPreferences p=ThemeConfig.prefs(context);
        String raw=p.getString(KEY,"0,1,2,3,4,5,6,7");
        ArrayList<Integer> ids=new ArrayList<>();
        HashSet<Integer> seen=new HashSet<>();
        for(String s:raw.split(",")) {
            try {
                int n=Integer.parseInt(s.trim());
                if(n>=0 && n<AppCatalog.CHANNELS.length && seen.add(n))ids.add(n);
            }catch(NumberFormatException ignored){}
        }
        return ids;
    }
    public static void save(Context context,List<Integer> order) {
        StringBuilder out=new StringBuilder();
        for(int id:order){if(out.length()>0)out.append(',');out.append(id);}
        ThemeConfig.prefs(context).edit().putString(KEY,out.toString()).apply();
    }
    public static void restore(Context context) {
        ThemeConfig.prefs(context).edit().remove(KEY).apply();
    }
}
