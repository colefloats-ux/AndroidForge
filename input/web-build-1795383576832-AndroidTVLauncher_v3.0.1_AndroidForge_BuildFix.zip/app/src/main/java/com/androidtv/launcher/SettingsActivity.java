package com.androidtv.launcher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Fully remote navigable settings. All changes are stored locally on the TV. */
public final class SettingsActivity extends Activity {
    private FrameLayout root;
    private LinearLayout items;
    private ImageView backdrop;
    private View firstOption;
    private View selectedOption;
    private ScrollView scroll;
    private final java.util.ArrayList<View> focusRows=new java.util.ArrayList<>();
    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        build();
    }
    private FrameLayout.LayoutParams pos(int width,int height,int gravity,int left,int top,int right,int bottom){
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(width<0?width:Ui.dp(this,width),height<0?height:Ui.dp(this,height),gravity);
        lp.setMargins(Ui.dp(this,left),Ui.dp(this,top),Ui.dp(this,right),Ui.dp(this,bottom));return lp;
    }
    private void build(){
        int lastFocused=-1;
        View last=getCurrentFocus();
        if(last!=null && last.getTag() instanceof Integer)lastFocused=(Integer)last.getTag();
        focusRows.clear();
        root=new FrameLayout(this);root.setBackgroundColor(0xFF1A153B);
        backdrop=new ImageView(this);backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        backdrop.setImageResource(ThemeConfig.wallpaper(ThemeConfig.themeIndex(this)));
        root.addView(backdrop,new FrameLayout.LayoutParams(-1,-1));
        View dim=new View(this);dim.setBackgroundColor(0xCE141028);root.addView(dim,new FrameLayout.LayoutParams(-1,-1));
        TextView title=Ui.label(this,"AndroidTV  /  Settings",29,Color.WHITE,true);
        root.addView(title,pos(550,47,Gravity.TOP|Gravity.LEFT,58,32,0,0));
        TextView back=Ui.label(this,"‹  Back to Home",17,0xFFE4D5FF,true);back.setGravity(Gravity.CENTER);
        back.setFocusable(true);back.setBackground(Ui.bgBorder(0x582C2559,9,0x8CC2AAF4,1,this));
        back.setOnFocusChangeListener((v,f)->back.setBackground(Ui.bgBorder(0x84493E77,9,f?Color.WHITE:0x8CC2AAF4,f?2:1,this)));
        back.setOnClickListener(v->finish());
        root.addView(back,pos(190,40,Gravity.RIGHT|Gravity.TOP,0,33,57,0));

        firstOption=null; selectedOption=null;
        scroll=new ScrollView(this);scroll.setClipToPadding(false);scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        root.addView(scroll,pos(-1,-1,Gravity.FILL,55,96,70,18));
        items=new LinearLayout(this);items.setOrientation(LinearLayout.VERTICAL);items.setFocusable(false);
        scroll.addView(items,new ScrollView.LayoutParams(-1,-2));
        addHeading("SEASONAL WALLPAPERS", "Pick one of eight original moving scenes, or follow the calendar automatically.");
        String selection=ThemeConfig.prefs(this).getString(ThemeConfig.KEY_THEME,"auto");
        addOption("●   Auto — switch with the seasons", "Spring: Mar–May  •  Summer: Jun–Aug  •  Autumn: Sep–Nov  •  Winter: Dec–Feb", "auto".equals(selection),()->chooseTheme("auto"));
        for(int i=0;i<ThemeConfig.IDS.length;i++){
            final int index=i;
            addThemeOption(index,ThemeConfig.IDS[i].equals(selection),()->chooseTheme(ThemeConfig.IDS[index]));
        }
        addHeading("HOME SCREEN CHANNELS", "Manage the tiles that appear on your Home screen.");
        addOption("Restore the eight original channel tiles", "Undo hidden or rearranged tiles and return to the approved order.",false,()->{
            new android.app.AlertDialog.Builder(this)
                .setTitle("Restore original Home tiles?")
                .setMessage("All eight channels will reappear in the original order. Your installed apps remain unchanged.")
                .setPositiveButton("Restore",(d,w)->{HomeTiles.restore(this);build();})
                .setNegativeButton("Cancel",null).show();
        });
        addHeading("VERSE OF THE DAY", "The golden card updates daily from VerseOfTheDay.com; its last successful verse stays available offline.");
        addOption("Verse source: VerseOfTheDay.com", "Tap the gold card on Home to read the full verse or visit the publisher.",false,()->{
            try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://www.verseoftheday.com/")));}
            catch(Exception ignored){new android.app.AlertDialog.Builder(this).setMessage("Install a browser to visit VerseOfTheDay.com.").setPositiveButton("OK",null).show();}
        });
        addHeading("MOTION & PERFORMANCE", "The effects are lightweight and remain behind your app tiles.");
        boolean effects=ThemeConfig.effects(this);
        addOption("Seasonal effects: "+(effects?"ON":"OFF"),"Enable or disable ambient particles and special launch transitions.",effects,()->{
            ThemeConfig.prefs(this).edit().putBoolean(ThemeConfig.KEY_EFFECTS,!ThemeConfig.effects(this)).apply();build();
        });
        int intensity=ThemeConfig.intensity(this);
        String value=intensity==0?"Off":intensity==1?"Subtle":"More";
        addOption("Animation level: "+value,"Press OK to cycle between Off, Subtle, and More.",false,()->{
            ThemeConfig.prefs(this).edit().putInt(ThemeConfig.KEY_INTENSITY,(ThemeConfig.intensity(this)+1)%3).apply();build();
        });
        boolean instant=ThemeConfig.instant(this);
        addOption("Instant app opening: "+(instant?"ON":"OFF"),
            instant?"Recommended: apps launch immediately; effects never delay them.":
                    "Cinematic mode: complete the ice/leaf effect before launching.",instant,()->{
            ThemeConfig.prefs(this).edit().putBoolean(ThemeConfig.KEY_INSTANT,!ThemeConfig.instant(this)).apply();build();
        });
        addHeading("DEFAULT LAUNCHER", "AndroidTV registers as a system Home candidate. Firmware controls final selection.");
        boolean isDefault=HomeRole.isDefault(this);
        addOption("Home app: "+(isDefault?"AndroidTV is default":"Not currently default"),
            isDefault?"Your TV currently recognizes AndroidTV as Home.":"Select AndroidTV as the Home app where supported.",isDefault,()->HomeRole.request(this));
        addOption("Set as default launcher", "Request Android's official Home role or open the system Home selection.",false,()->HomeRole.request(this));
        addOption("Setup for restricted TVs / ADB", "See the safe ADB command and limitations for locked manufacturers.",false,()->HomeRole.showRestrictedHelp(this));
        addOption("About this launcher", "8 channels · 8 seasonal wallpapers · Native Android TV remote controls · Version 3.0",false,()->{
            new android.app.AlertDialog.Builder(this).setTitle("AndroidTV Launcher")
                .setMessage("DIRECTV opens from Live TV. Hold OK on a channel for three seconds to move or remove it. The golden verse card refreshes from VerseOfTheDay.com and caches the last successful verse offline. Third-party launcher support depends on TV firmware.")
                .setPositiveButton("OK",null).show();
        });
        setContentView(root);
        View focus=(lastFocused>=0 && lastFocused<focusRows.size())?focusRows.get(lastFocused):
                (selectedOption!=null?selectedOption:firstOption);
        if(focus!=null)focus.requestFocus();
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==HomeRole.REQUEST_CODE)build();
    }
    private void chooseTheme(String id){
        ThemeConfig.prefs(this).edit().putString(ThemeConfig.KEY_THEME,id).apply();
        build();
    }
    private void addHeading(String heading,String description){
        TextView h=Ui.label(this,heading,16,0xFFDECAFF,true);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,Ui.dp(this,32));hp.topMargin=Ui.dp(this,16);items.addView(h,hp);
        TextView desc=Ui.label(this,description,14,0xFFD3CBE2,false);
        desc.setMaxLines(2);
        LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,Ui.dp(this,39));dp.bottomMargin=Ui.dp(this,3);items.addView(desc,dp);
    }
    private void addOption(String title,String description,boolean selected,Runnable onClick){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setGravity(Gravity.CENTER_VERTICAL);
        Ui.padding(row,this,16,8,10,9);
        row.setFocusable(true);row.setClickable(true);
        row.setBackground(Ui.bgBorder(selected?0xAB584492:0x771F1B3B,9,selected?0xFFC1ABF9:0x557C699F,selected?2:1,this));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,Ui.dp(this,71));lp.bottomMargin=Ui.dp(this,9);items.addView(row,lp);
        TextView titleView=Ui.label(this,(selected?"✓   ":"")+title,17,Color.WHITE,true);
        row.addView(titleView,new LinearLayout.LayoutParams(-1,Ui.dp(this,25)));
        TextView subtitle=Ui.label(this,description,13,0xFFE1DCEB,false);subtitle.setSingleLine(true);
        row.addView(subtitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        row.setTag(focusRows.size());focusRows.add(row);
        if(firstOption==null)firstOption=row;
        if(selected)selectedOption=row;
        row.setOnClickListener(v->onClick.run());
        row.setOnFocusChangeListener((v,focus)->{
            row.setBackground(Ui.bgBorder(focus?0xDD63519C:(selected?0xAB584492:0x771F1B3B),9,focus?Color.WHITE:(selected?0xFFC1ABF9:0x557C699F),focus?3:(selected?2:1),this));
        });
    }
    private int thumb(int index){
        switch(index){
            case 0:return R.drawable.thumb_spring_blossoms;
            case 1:return R.drawable.thumb_spring_garden;
            case 2:return R.drawable.thumb_summer_sunset;
            case 3:return R.drawable.thumb_summer_lake;
            case 4:return R.drawable.thumb_autumn_sunset;
            case 5:return R.drawable.thumb_autumn_breeze;
            case 6:return R.drawable.thumb_winter_snow;
            default:return R.drawable.thumb_winter_frozen;
        }
    }
    private void addThemeOption(int index,boolean selected,Runnable onClick){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);Ui.padding(row,this,9,6,11,6);
        row.setFocusable(true);row.setClickable(true);
        row.setBackground(Ui.bgBorder(selected?0xA65A438E:0x951E1A3C,9,selected?0xFFC8B2FF:0x597C6A98,selected?2:1,this));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,94));rp.bottomMargin=Ui.dp(this,7);
        items.addView(row,rp);
        ImageView preview=new ImageView(this);preview.setImageResource(thumb(index));
        preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        preview.setBackground(Ui.bg(0xFF2B2148,7,this));preview.setClipToOutline(true);
        preview.setFocusable(false);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(Ui.dp(this,140),Ui.dp(this,79));
        ip.rightMargin=Ui.dp(this,16);row.addView(preview,ip);
        LinearLayout labels=new LinearLayout(this);labels.setOrientation(LinearLayout.VERTICAL);
        labels.setGravity(Gravity.CENTER_VERTICAL);row.addView(labels,new LinearLayout.LayoutParams(0,-1,1));
        TextView label=Ui.label(this,(selected?"✓   ":"")+ThemeConfig.LABELS[index],17,Color.WHITE,true);
        labels.addView(label,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));
        TextView desc=Ui.label(this,ThemeConfig.DESCRIPTIONS[index],13,0xFFE4DBF2,false);
        desc.setMaxLines(2);labels.addView(desc,new LinearLayout.LayoutParams(-1,-2));
        row.setTag(focusRows.size());focusRows.add(row);
        if(firstOption==null)firstOption=row;
        if(selected)selectedOption=row;
        row.setOnClickListener(v->onClick.run());
        row.setOnFocusChangeListener((v,focus)->row.setBackground(Ui.bgBorder(
            focus?0xE05D448F:(selected?0xA65A438E:0x951E1A3C),9,
            focus?Color.WHITE:(selected?0xFFC8B2FF:0x597C6A98),focus?3:(selected?2:1),this)));
    }
}
