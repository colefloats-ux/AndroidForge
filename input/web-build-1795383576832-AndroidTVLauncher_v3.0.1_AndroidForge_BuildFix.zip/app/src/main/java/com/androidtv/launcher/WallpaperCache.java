package com.androidtv.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Decode seasonal JPEGs away from the UI thread; retain at most two high-quality images (~12MB). */
public final class WallpaperCache {
    private WallpaperCache() {}
    private static final ExecutorService IO=Executors.newSingleThreadExecutor();
    private static final Handler UI=new Handler(Looper.getMainLooper());
    private static final LruCache<Integer,Bitmap> CACHE=new LruCache<Integer,Bitmap>(14*1024*1024){
        @Override protected int sizeOf(Integer key,Bitmap value){return value.getByteCount();}
    };
    public static void set(ImageView view,int drawable){
        view.setTag(drawable);
        Bitmap hit;
        synchronized(CACHE){hit=CACHE.get(drawable);}
        if(hit!=null && !hit.isRecycled()){view.setImageBitmap(hit);return;}
        // A dark fallback is shown immediately; no image decoding blocks remote input.
        Context app=view.getContext().getApplicationContext();
        IO.execute(()->{
            Bitmap image=null;
            try{
                BitmapFactory.Options opts=new BitmapFactory.Options();
                opts.inPreferredConfig=Bitmap.Config.ARGB_8888;
                opts.inDither=true;
                image=BitmapFactory.decodeResource(app.getResources(),drawable,opts);
            }catch(Exception ignored){}
            final Bitmap decoded=image;
            if(decoded==null)return;
            synchronized(CACHE){CACHE.put(drawable,decoded);}
            UI.post(()->{
                if(Integer.valueOf(drawable).equals(view.getTag()))view.setImageBitmap(decoded);
            });
        });
    }
}
