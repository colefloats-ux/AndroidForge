package com.androidtv.launcher;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public final class Ui {
    private Ui() {}
    public static int dp(Context c, float v) {return (int)(v*c.getResources().getDisplayMetrics().density+0.5f);}
    public static TextView label(Context c,String s,float size,int color,boolean bold) {
        TextView v=new TextView(c);v.setText(s);v.setTextSize(TypedValue.COMPLEX_UNIT_SP,size);
        v.setTextColor(color);v.setGravity(Gravity.CENTER_VERTICAL);
        v.setIncludeFontPadding(false);
        if(bold)v.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        else v.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        return v;
    }
    public static GradientDrawable bg(int fill,float radius,Context c) {
        GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(c,radius));return d;
    }
    public static GradientDrawable bgBorder(int fill,float radius,int border,int thickness,Context c) {
        GradientDrawable d=bg(fill,radius,c);d.setStroke(dp(c,thickness),border);return d;
    }
    public static void padding(View v, Context c, int l,int t,int r,int b) {v.setPadding(dp(c,l),dp(c,t),dp(c,r),dp(c,b));}
    public static int white() {return Color.WHITE;}
    public static int muted() {return Color.rgb(224,218,239);}
}
