package com.androidtv.launcher;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Fast, non-blocking TV-friendly app launch transitions. */
public final class LaunchTransitionView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private float progress=0f;
    private int scene=0;
    private boolean animating=false;
    private ValueAnimator animator;
    public LaunchTransitionView(Context c){super(c);setVisibility(GONE);setFocusable(false);}
    /** In Instant mode the app starts on the same tap, never at animation completion.
     *  Cinematic mode is the explicit opt-in to a full pre-launch animation. */
    public void launch(int theme, boolean effects, boolean instant, Runnable action){
        if(animating) return; // Prevent accidental repeated OK presses.
        if(!effects || (theme!=5 && theme!=7)) { action.run(); return; }
        scene=theme;progress=0f;animating=true;setVisibility(VISIBLE);
        animator=ValueAnimator.ofFloat(0f,1f);
        animator.setDuration(theme==7 ? (instant?380:650) : (instant?290:420));
        final boolean waitForAnimation = !instant;
        animator.addUpdateListener(a->{progress=(float)a.getAnimatedValue();invalidate();});
        animator.addListener(new AnimatorListenerAdapter(){
            private boolean canceled=false;
            @Override public void onAnimationCancel(Animator a){canceled=true;}
            @Override public void onAnimationEnd(Animator a){
                animating=false;setVisibility(GONE);
                if(waitForAnimation && !canceled)action.run();
            }
        });
        animator.start();
        if(instant) action.run(); // No artificial launch delay.
    }
    public void stop(){
        if(animator!=null){animator.cancel();animator=null;}
        animating=false;setVisibility(GONE);
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);float w=getWidth(),h=getHeight();
        if(scene==7)frozen(c,w,h);else leaves(c,w,h);
    }
    private void frozen(Canvas c,float w,float h){
        // Visible ice grows across the entire launcher, fractures, and then bursts outward.
        float grow=Math.min(1f,progress/.51f);
        float fade=progress>.66f?Math.max(0f,1f-(progress-.66f)/.34f):1f;
        float cx=w*.44f,cy=h*.43f;
        float far=(float)Math.hypot(w,h)*1.13f;
        Path frozenArea=new Path();frozenArea.addCircle(cx,cy,far*grow,Path.Direction.CW);
        c.save();c.clipPath(frozenArea);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb((int)(190*fade),194,226,245));c.drawRect(0,0,w,h,p);
        p.setColor(Color.argb((int)(76*fade),110,191,238));
        for(int i=0;i<10;i++){
            float yy=h*(i+.3f)/10f;
            c.drawRect(0,yy,w,yy+h*.034f,p);
        }
        // Crystalline facets form while the glass freezes.
        for(int i=0;i<54;i++){
            float angle=(float)(i*2.399963),radius=far*(.15f+(i%9)*.08f);
            float x=cx+(float)Math.cos(angle)*radius;
            float y=cy+(float)Math.sin(angle)*radius;
            float edge=w*(.006f+(i%5)*.002f);
            Path facet=new Path();facet.moveTo(x,y-edge*1.8f);
            facet.lineTo(x+edge*1.1f,y+edge*.8f);
            facet.lineTo(x-edge*.8f,y+edge*1.25f);facet.close();
            p.setColor(Color.argb((int)(40*fade),255,255,255));c.drawPath(facet,p);
        }
        // Fractures radiate from the selected tile, branching across the frozen surface.
        if(progress>.31f){
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1.5f,w*.0017f));
            float crackReach=Math.min(1f,(progress-.31f)/.27f);
            for(int i=0;i<32;i++){
                float angle=(float)(i*2.3999632f);
                float length=(float)(far*(.28f+.65f*(i%7)/7f)*crackReach);
                float x2=cx+(float)Math.cos(angle)*length;
                float y2=cy+(float)Math.sin(angle)*length;
                Path crack=new Path();crack.moveTo(cx,cy);
                crack.lineTo(cx+(x2-cx)*.47f+7f,cy+(y2-cy)*.47f-8f);
                crack.lineTo(x2,y2);
                p.setColor(Color.argb((int)(222*fade),254,254,255));c.drawPath(crack,p);
                p.setStrokeWidth(Math.max(1.0f,w*.001f));
                p.setColor(Color.argb((int)(105*fade),20,75,130));c.drawPath(crack,p);
                p.setStrokeWidth(Math.max(1.5f,w*.0017f));
            }
        }
        c.restore();
        // As the ice bursts, polygonal shards fly to the edges and reveal the app launch.
        if(progress>.60f){
            float burst=(progress-.60f)/.40f;
            p.setStyle(Paint.Style.FILL);
            for(int i=0;i<43;i++){
                float angle=(float)(i*2.399963f);
                float spread=burst*burst;
                float x=cx+(float)Math.cos(angle)*far*.85f*spread;
                float y=cy+(float)Math.sin(angle)*far*.75f*spread;
                float size=w*(.011f+(i%5)*.004f)*(1f+.35f*burst);
                Path shard=new Path();shard.moveTo(x,y);
                shard.lineTo(x+(float)Math.cos(angle+.58f)*size*1.9f,y+(float)Math.sin(angle+.58f)*size*1.9f);
                shard.lineTo(x+(float)Math.cos(angle-1.1f)*size,y+(float)Math.sin(angle-1.1f)*size);
                shard.close();
                p.setColor(Color.argb((int)(201*(1-burst*.8f)),211,239,255));c.drawPath(shard,p);
            }
        }
        p.setStyle(Paint.Style.FILL);
    }
    private void leaves(Canvas c,float w,float h){
        p.setStyle(Paint.Style.FILL);
        for(int i=0;i<19;i++){
            float x=w*((i%8)*.14f-.12f+progress*1.3f);
            float y=h*((i%5)*.18f+.13f)+(float)Math.sin(progress*10+i)*h*.065f;
            float sz=w*(.006f+i%3*.002f);
            p.setColor(i%3==0?0xBDF2A14B:(i%3==1?0xBFB23F35:0xD5D87436));
            c.save();c.rotate(progress*430+i*27,x,y);
            c.drawOval(x-sz*1.2f,y-sz*.65f,x+sz*1.2f,y+sz*.65f,p);c.restore();
        }
    }
}
