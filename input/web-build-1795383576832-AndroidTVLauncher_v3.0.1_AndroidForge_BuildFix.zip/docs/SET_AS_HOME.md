# Set AndroidTV as your default Home app

The AndroidTV launcher is a real native **HOME** activity (Android manifest intent
filter `ACTION_MAIN` + `CATEGORY_HOME` + `CATEGORY_DEFAULT`) and also appears in
`LEANBACK_LAUNCHER` and `LAUNCHER` app lists. No root or special system permission
is requested by the APK.

1. Open AndroidTV, then Settings > **Set as default launcher**. On Android 10+
   where the Home role is available, this uses Android's official Home-role chooser.
2. Otherwise, the app opens the TV's Home-app settings, if the TV provides it.
3. If the TV firmware hides/blocks Home selection, open the in-app
   **Setup for restricted TVs / ADB** help screen. With user-approved ADB access,
   a supported device may accept:

   `adb shell cmd package set-home-activity com.androidtv.launcher/.MainActivity`

   To inspect the current Home handler:

   `adb shell cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME`

**Limitations:** Android TV manufacturers may lock the Home button to their
system launcher. A regular sideloaded APK cannot override protected settings,
grant itself system/privileged permissions, or guarantee that the command is
honored. The app deliberately does not disable system packages or use an
accessibility service to hijack the Home key.

## Instant versus Cinematic

* **Instant (default):** launch the app immediately after OK, without waiting for
  the leaf/ice transition. A short overlay may appear while Android switches
  apps; the full animation may be cut short by a fast app launch.
* **Cinematic:** complete the effects before starting the next app. The optional
  ice transition lasts 650ms, leaf sweep 420ms. This deliberately adds delay.
* Wallpapers decode on a background thread, channel launch intents are warmed
  on a background thread, and particle animation pauses when leaving Home.
