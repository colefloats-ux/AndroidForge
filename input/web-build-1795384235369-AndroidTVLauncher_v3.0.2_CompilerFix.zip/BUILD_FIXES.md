# AndroidTV Launcher v3.0.2 — compiler correction

- Fixed Java variable shadowing in VerseOfDay.fromWebPage: the HTTP read buffer is now `htmlLine`, while the subsequent foreach variable stays `line`.
- Preserved Gradle build files, application ID, themes, visual assets, and TV functionality.
- Version code 6, version name 3.0.2.
- Build verified only after successful GitHub Actions run; do not assume success before it completes.
