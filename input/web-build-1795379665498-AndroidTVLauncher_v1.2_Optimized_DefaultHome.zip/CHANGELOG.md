# AndroidTV Launcher — Changes in 1.2.0

## Launch performance
- **Instant** mode is the default. The activity launch is initiated on the OK tap, with no intentional pause for animations.
- **Cinematic** mode is optional for people who want the full ice-shatter (650ms) or autumn leaf sweep (420ms) to finish before app launch.
- Installed streaming launch intents are prefetched in a background thread, then cached for the next tap.
- Seasonal wallpaper decoding occurs off the UI thread and loads only on actual theme changes; two quality bitmaps can stay cached.
- Particle effects run at a modest refresh cadence, pause when another application is in the foreground, and resume on return.
- Fixed-size responsive 4x2 grid is aligned more closely to the approved compact screenshots.

## Default Home setup
- The manifest exposes HOME + DEFAULT, LEANBACK_LAUNCHER, and LAUNCHER intent filters.
- Android's Home role is requested through its public consent interface when available.
- Settings reports current default Home status, with fallback Home settings and user-approved ADB setup instructions.
- A one-time setup dialog appears the first time the app opens when it is not yet Home.
- No unsafe attempts to disable manufacturer packages, claim protected privileges, or intercept the Home key.

## Channel graphics
- Seven brand tiles were cropped from the agreed visual reference, cleaned at the edges, and integrated as launcher image assets.
- The custom purple **Live TV** tile remains the sole entry for DIRECTV; no DIRECTV logo is displayed on Home.
- The active white outline is drawn by Android on the focused tile (not hardcoded into the bitmap).

## Known boundaries
- This is a source project, not a precompiled APK. Android SDK compilation and Android TV verification still need to be performed.
- Third-party Home selection can be blocked by TV firmware; no normal APK can guarantee override.
- Instant launch can interrupt the visual effect as soon as the streaming app comes forward. Select Cinematic if seeing the entire ice effect matters more than immediate opening.
