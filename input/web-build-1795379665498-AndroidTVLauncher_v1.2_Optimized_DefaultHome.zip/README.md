# AndroidTV Launcher — native Android TV project

This ZIP contains the **complete source project** for a native Android TV launcher. It is not a web site, HTML-to-APK export, or already compiled APK. It includes Android Gradle build files, Java application code, bundled seasonal artwork, TV channel graphics, settings, and app launch logic.

## Create your APK from this ZIP

Use an online Android builder that explicitly supports **Android Studio / Gradle projects**. Upload the entire ZIP without removing its folders. Configure Java 17 and Android SDK Platform 35 and run:

```shell
gradle assembleDebug
```

On a Linux/macOS builder without Gradle installed, `./gradlew assembleDebug` can bootstrap Gradle 8.9 via curl/wget if the builder has network access and Android SDK installed. `gradlew.bat` invokes installed Gradle on Windows.

The APK is generated at:

```
app/build/outputs/apk/debug/app-debug.apk
```

**Alternate free cloud build:** The repository includes `.github/workflows/build-apk.yml`. If you upload the project to a GitHub repository and trigger the Build APK workflow, it uploads a downloadable debug APK. GitHub has account and usage limits.

## Exactly what is included

- **Roku-inspired compact home:** `AndroidTV` title, live clock, lavender highlighted Home sidebar above Search and Settings, white remote-focus indicator, four columns × two rows of channel tiles, right-hand All Apps chevron, and a bottom-center Google-G/Gemini entry.
- **Channels, in order:** `Live TV` → DIRECTV (`com.att.tv`), Stremio, Hulu, Disney+, HBO Max, Peacock, Prime Video, Paramount+. The DIRECTV logo is deliberately **not** shown on the Live TV tile. Other apps need to be installed separately.
- **All Apps:** The right chevron opens a native list of other installed apps; nothing extra is added to the fixed home channel order.
- **Remote support:** D-pad navigation, focus outlines, OK to select, Back, voice search when supported by the TV. Channel logos are cropped from the approved compact home-screen reference, and the focus border is a live UI element, not baked into graphics.
- **Eight Full HD wallpaper files**, two per season, with distinct scenic variants and thumbnail previews. Backgrounds work offline.
- **Theme effects:** Spring petal fall / garden butterflies; summer fireflies / shimmering lake; autumn sparse leaves (four every ~10 seconds) / continuous drifting leaves with an app-opening sweep; winter subtle snow / freeze, cracking glass, and ice-shard burst. In **Instant mode (default)** apps begin launching immediately (the OS may cover the overlay); full **before-launch** transitions are optional in Cinematic mode.
- **Settings:** Automatic calendar switching (spring Mar–May; summer Jun–Aug; fall Sep–Nov; winter Dec–Feb), manual theme override, ambient animations on/off, intensity Off/Subtle/More, Instant/Cinematic launch modes, official Home-role request, Home-app status and manufacturer-restriction/ADB setup help.
- **Search:** Text or supported voice input, local search of installed TV apps, plus web search and Gemini. Gemini opens `https://gemini.google.com/app` in the installed browser; typed/spoken prompts are copied to the clipboard for pasting.

### Integration boundaries

1. **Gemini is not a built-in licensed federated streaming search engine.** Streaming providers generally do not expose an unrestricted cross-provider movie/TV catalog API to a third-party launcher. The app searches installed apps and opens Gemini / web search. It does *not* claim in-app searches of DIRECTV, Hulu, etc.
2. **TV makers may restrict HOME replacement.** The app declares `HOME`, `DEFAULT`, `LEANBACK_LAUNCHER`, and `LAUNCHER` filters; requests the official Home role; reports current status; and provides safe ADB guidance. It cannot bypass manufacturer security restrictions; see `docs/SET_AS_HOME.md`.
3. **All eight video services remain separate apps.** The launcher opens those installed apps; it does not include subscriptions or streaming content.
4. **An external Android SDK is required for compilation.** This ZIP has been inspected offline, but because Android SDK/Gradle is unavailable in the authoring environment, no device or APK compilation test has been performed. A successful build and installation must still be confirmed.

## Android project configuration

- Java 17, native platform Views; no third-party runtime libraries.
- Gradle Android plugin **8.6.1**, Gradle **8.9**, `compileSdk 35`, `minSdk 23`, `targetSdk 32`.
- Source: `app/src/main/java/com/androidtv/launcher/`
- Media: `app/src/main/res/drawable-nodpi/`
- App manifest: `app/src/main/AndroidManifest.xml`
- Build workflow: `.github/workflows/build-apk.yml`
- App version: **1.2.0**

## If something doesn't launch

Install the matching streaming app from your TV's Play Store first. The Home screen uses known package IDs (DIRECTV is confirmed as `com.att.tv`), with a package-label matching fallback where possible. If an app is absent, the tile presents an installation shortcut instead of failing silently. If the Gemini website cannot open, install a TV-compatible web browser or use the TV/web search option.

## Performance engineering (v1.2)

- **No artificial delay on app selection:** `startActivity()` is issued on the OK tap in Instant mode (enabled by default). The old 540–790ms transition blocking has been removed.
- **Fast returning Home:** wallpapers are loaded only on theme changes and decoded off the UI thread, with a small in-memory cache.
- **Fast channel lookup:** installed launch intents are prefetched on a background worker and cached for later taps.
- **Efficient effects:** lightweight native Canvas particles at ~16fps and rendering paused while other apps are foreground.
- **Optional Cinematic:** Settings lets the user opt into full freeze/shatter or leaf-sweep pre-launch effects if they prefer those visuals over the shortest possible launch time.
- **Default Home:** first-open setup prompt, RoleManager request, Home-app status, settings fallback, and ADB guidance.

No source-only project can guarantee launch speed or compatibility on an untested device. Actual startup time also depends on the TV processor, installed app, networking, and streaming-service startup.
