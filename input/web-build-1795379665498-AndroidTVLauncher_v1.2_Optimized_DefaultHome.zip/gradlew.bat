@echo off
REM The simplest way on Windows is to use the Gradle installed by Android Studio.
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle is not on PATH. Open this project in Android Studio to install build tools.
  exit /b 1
)
gradle %*
