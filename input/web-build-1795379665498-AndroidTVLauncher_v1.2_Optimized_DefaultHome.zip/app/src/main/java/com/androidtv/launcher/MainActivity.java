package com.androidtv.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int VOICE_REQUEST=30;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final SimpleDateFormat timeFormat=new SimpleDateFormat("h:mm a",Locale.US);
    private final Runnable clockUpdater=new Runnable(){
        @Override public void run(){if(clock!=null)clock.setText(timeFormat.format(new Date()));handler.postDelayed(this,30000);}
    };
    private FrameLayout root;
    private ImageView wallpaper;
    private ThemeEffectsView ambient;
    private LaunchTransitionView transition;
    private TextView clock;
    private View firstChannel;
    private int currentTheme=4;
    private boolean currentEffects=true;
    private int currentIntensity=1;
    private int shownWallpaper=-1;
    private long lastLaunchTap=0L;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        immersive();
        createHome();
        showSetupOnFirstOpen();
    }
    /** One-time, remote-navigable shortcut for choosing a default Home app. */
    private void showSetupOnFirstOpen(){
        if(HomeRole.isDefault(this))return;
        android.content.SharedPreferences prefs=ThemeConfig.prefs(this);
        if(prefs.getBoolean("home_intro_shown",false))return;
        prefs.edit().putBoolean("home_intro_shown",true).apply();
        root.post(()->new AlertDialog.Builder(this)
            .setTitle("Use AndroidTV as your Home screen?")
            .setMessage("To open AndroidTV when you press the TV Home button, choose it as your default Home app. Some manufacturers restrict this setting.")
            .setPositiveButton("Set as default",(d,w)->HomeRole.request(this))
            .setNegativeButton("Later",null).show());
    }
    private void immersive(){
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
    @Override public void onConfigurationChanged(Configuration newConfig){super.onConfigurationChanged(newConfig);createHome();}
    private FrameLayout.LayoutParams pos(int width,int height,int gravity,int left,int top,int right,int bottom){
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(width<0?width:Ui.dp(this,width),height<0?height:Ui.dp(this,height),gravity);
        p.setMargins(Ui.dp(this,left),Ui.dp(this,top),Ui.dp(this,right),Ui.dp(this,bottom));return p;
    }
    private void createHome(){
        float density=getResources().getDisplayMetrics().density;
        int screenW=Math.round(getResources().getDisplayMetrics().widthPixels/density);
        int screenH=Math.round(getResources().getDisplayMetrics().heightPixels/density);
        root=new FrameLayout(this);root.setBackgroundColor(Color.rgb(38,29,69));
        root.setFocusableInTouchMode(true);
        wallpaper=new ImageView(this);wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(wallpaper,new FrameLayout.LayoutParams(-1,-1));
        View veil=new View(this);
        GradientDrawable veilGradient=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0x8D16122E,0x5821163C,0x34151230,0x221A163A});
        veil.setBackground(veilGradient);root.addView(veil,new FrameLayout.LayoutParams(-1,-1));
        ambient=new ThemeEffectsView(this);root.addView(ambient,new FrameLayout.LayoutParams(-1,-1));

        TextView title=Ui.label(this,"AndroidTV",30,Color.WHITE,true);title.setLetterSpacing(-.035f);
        root.addView(title,pos(300,48,Gravity.TOP|Gravity.LEFT,Math.round(screenW*.085f),Math.round(screenH*.06f),0,0));
        clock=Ui.label(this,"",20,Color.WHITE,true);clock.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        root.addView(clock,pos(150,38,Gravity.TOP|Gravity.RIGHT,0,Math.round(screenH*.066f),Math.round(screenW*.055f),0));

        // Geometry measured from the user-approved compact 16:9 Roku-style reference.
        int sidebarTop=Math.max(100,Math.round(screenH*.258f));
        LinearLayout sidebar=new LinearLayout(this);sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setFocusable(false);
        root.addView(sidebar,pos(Math.round(screenW*.24f),-2,Gravity.TOP|Gravity.LEFT,
            Math.round(screenW*.062f),sidebarTop,0,0));
        makeSidebarItem(sidebar,"", "Home",()->{if(firstChannel!=null)firstChannel.requestFocus();},true);
        makeSidebarItem(sidebar,"", "Search",this::promptSearch,false);
        makeSidebarItem(sidebar,"", "Settings",()->startActivity(new Intent(this,SettingsActivity.class)),false);

        int left=Math.round(screenW*.342f);
        int gridTop=Math.max(100,Math.round(screenH*.255f));
        int spacing=Math.max(6,Math.round(screenW*.008f));
        int available=Math.max(0,screenW-left-Math.round(screenW*.035f));
        int tileW=Math.max(70,Math.min(Math.round(screenW*.1365f),(available-spacing*4)/4));
        int tileH=Math.max(46,Math.round(tileW*.64f));
        GridLayout grid=new GridLayout(this);grid.setColumnCount(4);grid.setRowCount(2);
        for(int i=0;i<AppCatalog.CHANNELS.length;i++){
            final int idx=i;
            View tile=makeChannel(AppCatalog.CHANNELS[i],tileW,tileH,()->openChannel(idx));
            GridLayout.LayoutParams gp=new GridLayout.LayoutParams(GridLayout.spec(i/4),GridLayout.spec(i%4));
            gp.width=Ui.dp(this,tileW);gp.height=Ui.dp(this,tileH);
            gp.setMargins(Ui.dp(this,spacing/2),Ui.dp(this,spacing/2),Ui.dp(this,spacing/2),Ui.dp(this,spacing/2));
            grid.addView(tile,gp);
            if(i==0)firstChannel=tile;
        }
        root.addView(grid,pos(-2,-2,Gravity.TOP|Gravity.LEFT,left,gridTop,0,0));
        TextView more=Ui.label(this,"›",37,0xC1FFFFFF,false);
        more.setGravity(Gravity.CENTER);
        more.setFocusable(true);more.setClickable(true);
        more.setContentDescription("Show all installed apps");
        more.setOnClickListener(v->startActivity(new Intent(this,AllAppsActivity.class)));
        more.setOnFocusChangeListener((v,f)->{
            more.setTextColor(f?Color.WHITE:0xC1FFFFFF);
            more.setBackground(f?Ui.bgBorder(0xA35E4196,10,Color.WHITE,2,this):null);
        });
        int arrowLeft=left+(tileW+spacing)*4+8;
        if(arrowLeft<screenW-40)root.addView(more,pos(34,64,Gravity.TOP|Gravity.LEFT,arrowLeft,gridTop+tileH/2+7,0,0));

        // Persistent bottom-center Gemini / TV search entry (remote and voice friendly).
        int barW=Math.max(280,Math.round(screenW*.52f));
        FrameLayout searchBar=new FrameLayout(this);searchBar.setFocusable(true);searchBar.setClickable(true);
        searchBar.setContentDescription("Gemini search. Press OK to type or use voice.");
        searchBar.setBackground(Ui.bgBorder(0xD930294B,24,0x8CBEAAEE,1,this));
        searchBar.setOnClickListener(v->promptSearch());
        searchBar.setOnFocusChangeListener((v,has)->{
            v.setBackground(Ui.bgBorder(has?0xDE453467:0xD930294B,24,has?0xFFD8C6FF:0x8CBEAAEE,has?3:1,this));
            v.animate().scaleX(has?1.025f:1).scaleY(has?1.025f:1).setDuration(130).start();
        });
        ImageView g=new ImageView(this);g.setScaleType(ImageView.ScaleType.FIT_CENTER);
        g.setImageResource(R.drawable.google_g);
        searchBar.addView(g,pos(33,33,Gravity.LEFT|Gravity.CENTER_VERTICAL,11,0,0,0));
        TextView hint=Ui.label(this,"Ask Gemini or search for anything",14,0xFFEAE6FF,false);
        hint.setSingleLine(true);hint.setEllipsize(android.text.TextUtils.TruncateAt.END);
        searchBar.addView(hint,pos(-1,-1,Gravity.FILL,53,0,54,0));
        ImageView mic=new ImageView(this);
        mic.setScaleType(ImageView.ScaleType.FIT_CENTER);
        mic.setImageResource(R.drawable.mic_white);
        mic.setPadding(Ui.dp(this,11),Ui.dp(this,9),Ui.dp(this,11),Ui.dp(this,9));
        mic.setFocusable(true);mic.setClickable(true);
        mic.setContentDescription("Voice search");
        mic.setOnClickListener(v->voiceSearch());
        searchBar.addView(mic,pos(43,-1,Gravity.RIGHT|Gravity.TOP,0,0,6,0));
        root.addView(searchBar,pos(barW,49,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL,0,0,0,Math.round(screenH*.055f)));

        transition=new LaunchTransitionView(this);
        root.addView(transition,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        refreshTheme();
        AppCatalog.prewarm(this);
        if(firstChannel!=null)firstChannel.requestFocus();
    }
    private void makeSidebarItem(LinearLayout parent,String icon,String text,Runnable action,boolean active){
        LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);
        line.setOrientation(LinearLayout.HORIZONTAL);Ui.padding(line,this,12,0,6,0);
        line.setFocusable(true);line.setClickable(true);
        line.setBackground(Ui.bg(active?0x85573F9F:0x00000000,8,this));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,Ui.dp(this,38));lp.bottomMargin=Ui.dp(this,5);
        parent.addView(line,lp);
        TextView label=Ui.label(this,text,18,Color.WHITE,active);
        LinearLayout.LayoutParams labelParams=new LinearLayout.LayoutParams(-1,-1);
        labelParams.leftMargin=Ui.dp(this,9);line.addView(label,labelParams);
        line.setOnClickListener(v->action.run());
        line.setOnFocusChangeListener((v,has)->line.setBackground(Ui.bgBorder(has?0xD16A4AA7:(active?0x85573F9F:0x00000000),8,has?Color.WHITE:Color.TRANSPARENT,has?2:0,this)));
    }
    private int tileArt(int index){
        switch(index){
            case 0:return R.drawable.tile_live;
            case 1:return R.drawable.tile_stremio;
            case 2:return R.drawable.tile_hulu;
            case 3:return R.drawable.tile_disney;
            case 4:return R.drawable.tile_max;
            case 5:return R.drawable.tile_peacock;
            case 6:return R.drawable.tile_prime;
            default:return R.drawable.tile_paramount;
        }
    }
    private View makeChannel(AppCatalog.Channel channel,int tileW,int tileH,Runnable click){
        FrameLayout tile=new FrameLayout(this);
        tile.setFocusable(true);tile.setClickable(true);
        tile.setContentDescription(channel.title+" channel");
        tile.setBackground(Ui.bg(channel.color,7,this));
        tile.setClipToOutline(true);
        tile.setElevation(Ui.dp(this,2));
        int i=java.util.Arrays.asList(AppCatalog.CHANNELS).indexOf(channel);
        ImageView artwork=new ImageView(this);
        artwork.setScaleType(ImageView.ScaleType.FIT_XY);
        artwork.setImageResource(tileArt(i));
        artwork.setFocusable(false);
        tile.addView(artwork,new FrameLayout.LayoutParams(-1,-1));
        tile.setForeground(Ui.bgBorder(Color.TRANSPARENT,7,0x00000000,0,this));
        tile.setOnClickListener(v->click.run());
        tile.setOnFocusChangeListener((v,focused)->{
            tile.setForeground(Ui.bgBorder(Color.TRANSPARENT,7,focused?0xFFFFFFFF:0x00000000,focused?2:0,this));
            tile.setElevation(Ui.dp(this,focused?9:2));
            tile.animate().scaleX(focused?1.018f:1).scaleY(focused?1.018f:1).setDuration(110).start();
        });
        return tile;
    }
    private void refreshTheme(){
        currentTheme=ThemeConfig.themeIndex(this);
        currentEffects=ThemeConfig.effects(this);
        currentIntensity=ThemeConfig.intensity(this);
        if(shownWallpaper!=currentTheme){
            shownWallpaper=currentTheme;
            WallpaperCache.set(wallpaper,ThemeConfig.wallpaper(currentTheme));
        }
        ambient.setScene(currentTheme,currentEffects?currentIntensity:0);
    }
    private void openChannel(int index){
        long now=SystemClock.uptimeMillis();
        if(now-lastLaunchTap<230L)return; // Ignore duplicate OK repeats, never delay first press.
        lastLaunchTap=now;
        AppCatalog.Channel channel=AppCatalog.CHANNELS[index];
        transition.launch(currentTheme,currentEffects && currentIntensity>0,ThemeConfig.instant(this),
            ()->AppCatalog.open(this,channel));
    }
    private void promptSearch(){
        EditText input=new EditText(this);input.setSingleLine(true);input.setTextSize(18);
        input.setInputType(InputType.TYPE_CLASS_TEXT);input.setHint("Movies, apps, questions…");
        Ui.padding(input,this,20,8,20,8);
        new AlertDialog.Builder(this).setTitle("Search apps and ask Gemini")
                .setView(input)
                .setPositiveButton("Search",(d,w)->universalSearch(input.getText().toString()))
                .setNeutralButton("Gemini",(d,w)->openGemini(input.getText().toString()))
                .setNegativeButton("Cancel",null).show();
    }
    /** Searches installed applications locally. Gemini and a web search remain selectable for other queries. */
    private void universalSearch(String phrase){
        final String query=phrase.trim();
        if(query.isEmpty()){promptSearch();return;}
        final java.util.ArrayList<String> labels=new java.util.ArrayList<>();
        final java.util.ArrayList<Runnable> actions=new java.util.ArrayList<>();
        String lowered=query.toLowerCase(Locale.US);
        for(AppCatalog.Channel channel:AppCatalog.CHANNELS){
            if(channel.title.toLowerCase(Locale.US).contains(lowered) ||
               channel.search.toLowerCase(Locale.US).contains(lowered) ||
               (channel.title.equals("Live TV") && (lowered.contains("tv") || lowered.contains("directv")))){
                labels.add("Open " + channel.title + (channel.title.equals("Live TV")?" (DIRECTV)":""));
                actions.add(()->AppCatalog.open(this,channel));
            }
        }
        // Search all additional installed apps shown in All Apps, not just the eight home tiles.
        android.content.pm.PackageManager pm=getPackageManager();
        java.util.HashSet<String> seen=new java.util.HashSet<>();
        for(String category:new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER,Intent.CATEGORY_LAUNCHER}) {
            Intent intent=new Intent(Intent.ACTION_MAIN);intent.addCategory(category);
            try{
                for(android.content.pm.ResolveInfo info:pm.queryIntentActivities(intent,0)) {
                    if(info.activityInfo==null)continue;
                    String pkg=info.activityInfo.packageName;
                    if(pkg.equals(getPackageName()) || !seen.add(pkg))continue;
                    String name=String.valueOf(info.loadLabel(pm));
                    if(!name.toLowerCase(Locale.US).contains(lowered))continue;
                    // Avoid duplicate hits when a fixed channel already represents this application.
                    boolean homeChannel=false;
                    for(AppCatalog.Channel channel:AppCatalog.CHANNELS)
                        for(String known:channel.packages)if(pkg.equals(known))homeChannel=true;
                    if(homeChannel)continue;
                    labels.add("Open " + name);
                    actions.add(()->{
                        try{
                            Intent launch=pm.getLeanbackLaunchIntentForPackage(pkg);
                            if(launch==null)launch=pm.getLaunchIntentForPackage(pkg);
                            if(launch!=null)startActivity(launch);
                        }catch(Exception e){Toast.makeText(this,"Unable to open " + name,Toast.LENGTH_SHORT).show();}
                    });
                }
            }catch(Exception ignored){}
        }
        labels.add("Ask Gemini (opens browser)");actions.add(()->openGemini(query));
        labels.add("Search the web");actions.add(()->tvSearch(query));
        new AlertDialog.Builder(this).setTitle("Results for “"+query+"”")
            .setItems(labels.toArray(new String[0]),(d,index)->actions.get(index).run())
            .setNegativeButton("Cancel",null).show();
    }
    private void voiceSearch(){
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT,"What would you like to find?");
        try{startActivityForResult(i,VOICE_REQUEST);}catch(ActivityNotFoundException e){
            Toast.makeText(this,"Voice recognition isn't available on this TV. Use OK to type.",Toast.LENGTH_LONG).show();promptSearch();
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==VOICE_REQUEST && result==RESULT_OK && data!=null){
            ArrayList<String> words=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(words!=null && !words.isEmpty())universalSearch(words.get(0));
        }
    }
    private void openGemini(String query){
        if(!query.trim().isEmpty()){
            // Public Gemini web does not provide a supported Android TV deep link for directly submitting prompts.
            ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            if(clipboard!=null)clipboard.setPrimaryClip(ClipData.newPlainText("Gemini prompt",query.trim()));
            Toast.makeText(this,"Prompt copied. Paste into Gemini to ask.",Toast.LENGTH_LONG).show();
        }
        try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://gemini.google.com/app")));}
        catch(Exception e){Toast.makeText(this,"Install a browser to open Gemini, or select TV search.",Toast.LENGTH_LONG).show();}
    }
    private void tvSearch(String query){
        if(query.trim().isEmpty()){promptSearch();return;}
        Intent i=new Intent(Intent.ACTION_WEB_SEARCH);i.putExtra(SearchManager.QUERY,query.trim());
        try{startActivity(i);}catch(ActivityNotFoundException e){
            try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(query.trim()))));}
            catch(Exception ignored){Toast.makeText(this,"No search app or browser is installed.",Toast.LENGTH_LONG).show();}
        }
    }
    @Override protected void onResume(){super.onResume();immersive();if(wallpaper!=null){refreshTheme();ambient.start();}handler.removeCallbacks(clockUpdater);clockUpdater.run();}
    @Override protected void onPause(){
        if(ambient!=null)ambient.stop();
        if(transition!=null)transition.stop();
        handler.removeCallbacks(clockUpdater);
        super.onPause();
    }
    @Override protected void onDestroy(){handler.removeCallbacks(clockUpdater);super.onDestroy();}
    @Override public void onBackPressed(){if(firstChannel!=null)firstChannel.requestFocus();else super.onBackPressed();}
}
