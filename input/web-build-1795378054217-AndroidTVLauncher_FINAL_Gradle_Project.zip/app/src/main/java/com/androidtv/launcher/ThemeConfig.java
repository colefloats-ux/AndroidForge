package com.androidtv.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Calendar;

public final class ThemeConfig {
    private ThemeConfig() {}
    public static final String PREFS = "androidtv_settings";
    public static final String KEY_THEME = "theme";
    public static final String KEY_EFFECTS = "effects";
    public static final String KEY_INTENSITY = "intensity";

    public static final String[] IDS = {"spring_blossoms", "spring_garden", "summer_sunset", "summer_lake", "autumn_sunset", "autumn_breeze", "winter_snow", "winter_frozen"};
    public static final String[] LABELS = {"Spring • Blossoms", "Spring • Enchanted Garden", "Summer • Sunset Fireflies", "Summer • Shimmering Lake", "Autumn • Sunset Leaves", "Autumn • Breezy Woods", "Winter • Gentle Snowfall", "Winter • Frozen Shatter"};
    public static final String[] DESCRIPTIONS = {
            "Soft pink petals drift across a flowering hillside.",
            "Butterflies float gently through an enchanted garden.",
            "Warm sunset with quietly blinking fireflies.",
            "Subtle reflections shimmer across the summer lake.",
            "3–4 autumn leaves fall roughly once every 10 seconds.",
            "Drifting foliage; a swirling-leaf app-opening transition.",
            "Occasional small snowflakes drift across the screen.",
            "Frost covers the screen and shatters when an app opens."
    };

    public static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    public static int themeIndex(Context c) {
        String chosen = prefs(c).getString(KEY_THEME, "auto");
        if ("auto".equals(chosen)) {
            int month=Calendar.getInstance().get(Calendar.MONTH);
            if (month>=2 && month<=4) return 0;
            if (month>=5 && month<=7) return 2;
            if (month>=8 && month<=10) return 4;
            return 6;
        }
        for (int i=0;i<IDS.length;i++) if (IDS[i].equals(chosen)) return i;
        return 4;
    }
    public static int wallpaper(int i) {
        switch(i) {
            case 0:return R.drawable.bg_spring_blossoms;
            case 1:return R.drawable.bg_spring_garden;
            case 2:return R.drawable.bg_summer_sunset;
            case 3:return R.drawable.bg_summer_lake;
            case 4:return R.drawable.bg_autumn_sunset;
            case 5:return R.drawable.bg_autumn_breeze;
            case 6:return R.drawable.bg_winter_snow;
            default:return R.drawable.bg_winter_frozen;
        }
    }
    public static boolean effects(Context c) { return prefs(c).getBoolean(KEY_EFFECTS,true); }
    public static int intensity(Context c) { return prefs(c).getInt(KEY_INTENSITY,1); }
}
