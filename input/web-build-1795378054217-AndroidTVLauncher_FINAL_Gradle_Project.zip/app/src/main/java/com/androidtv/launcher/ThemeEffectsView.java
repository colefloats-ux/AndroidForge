package com.androidtv.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.SystemClock;
import android.view.View;

/** Lightweight ambient effects rendered directly on Canvas, with no external animations or video. */
public final class ThemeEffectsView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private int theme=4,intensity=1;
    private boolean running=false;
    public ThemeEffectsView(Context context){super(context);setClickable(false);setFocusable(false);}
    public void setScene(int scene,int newIntensity){theme=scene;intensity=newIntensity;invalidate();}
    public void start(){running=true;postInvalidateOnAnimation();}
    public void stop(){running=false;}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        if(!running||intensity==0)return;
        float w=getWidth(),h=getHeight();
        if(w<=0||h<=0)return;
        long now=SystemClock.uptimeMillis();
        float time=now/1000f;
        switch(theme){
            case 0: petalFall(c,w,h,time,6);break;
            case 1: petalFall(c,w,h,time,3);butterflies(c,w,h,time);break;
            case 2: fireflies(c,w,h,time);break;
            case 3: lakeRipples(c,w,h,time);break;
            case 4: seasonalLeaves(c,w,h,now,true);break;
            case 5: seasonalLeaves(c,w,h,now,false);break;
            case 6: snow(c,w,h,time,10);break;
            case 7: snow(c,w,h,time,5);break;
            default:break;
        }
        postInvalidateDelayed(45L);
    }
    private void seasonalLeaves(Canvas c,float w,float h,long now,boolean intermittent) {
        float cycle=(now%10000L)/1000f;
        if(intermittent && cycle>4.2f)return; // 3–4 leaves approximately every ten seconds
        int count=intermittent?4:8;
        float t=intermittent?cycle:now/1000f;
        for(int i=0;i<count;i++){
            float x=(w*(0.06f+i*.132f)+w*.06f*(float)Math.sin(t*.8+i*1.6))%w;
            float yy=intermittent ? (-h*.12f+i*h*.07f+t*h*.29f) : ((t*.07f+i*.14f)%1.4f)*h-h*.2f;
            if(yy<0||yy>h)continue;
            int col=(i%3==0)?Color.rgb(241,149,75):((i%3==1)?Color.rgb(184,66,43):Color.rgb(219,108,55));
            drawLeaf(c,x,yy,Math.max(5,w*.0065f),t+i,col);
        }
    }
    private void drawLeaf(Canvas c,float x,float y,float radius,float spin,int col){
        c.save();c.rotate((spin*58)%360,x,y);
        p.setColor(col);p.setAlpha(190);p.setStyle(Paint.Style.FILL);
        Path leaf=new Path();leaf.moveTo(x,y-radius*1.4f);leaf.quadTo(x+radius*1.2f,y-radius,x+radius*.9f,y);
        leaf.quadTo(x+radius*.35f,y+radius*1.1f,x,y+radius*1.2f);
        leaf.quadTo(x-radius*1.2f,y+radius*.25f,x-radius,y-radius*.3f);
        leaf.close();c.drawPath(leaf,p);
        p.setColor(0xA85B2C24);p.setStrokeWidth(Math.max(1,radius*.12f));c.drawLine(x,y-radius,x,y+radius*1.35f,p);
        c.restore();
    }
    private void petalFall(Canvas c,float w,float h,float t,int count){
        for(int i=0;i<count*intensity;i++){
            float yy=(((t*.085f+i*.2f)%1.35f)-.17f)*h;
            float xx=w*(.1f+i*.14f)+w*.05f*(float)Math.sin(t*.65f+i);
            c.save();c.rotate(t*24+i*35,xx,yy);
            p.setColor(i%2==0?0xBDF6C2D7:0xADEBA8C2);
            c.drawOval(xx-w*.0035f,yy-h*.008f,xx+w*.0035f,yy+h*.008f,p);c.restore();
        }
    }
    private void butterflies(Canvas c,float w,float h,float t){
        for(int i=0;i<3*intensity;i++){
            float x=w*(.16f+.27f*i)+w*.03f*(float)Math.sin(t*.5+i);
            float y=h*(.2f+.12f*i)+h*.055f*(float)Math.sin(t*1.05+i*2);
            float span=w*.006f*(.65f+.35f*Math.abs((float)Math.sin(t*7+i)));
            p.setColor(0xB5D4A5FD);
            c.drawOval(x-span*2,y-span,x,y+span,p);
            c.drawOval(x,y-span,x+span*2,y+span,p);
            p.setColor(0xDBFCDBF2);c.drawLine(x,y-span,x,y+span,p);
        }
    }
    private void fireflies(Canvas c,float w,float h,float t){
        for(int i=0;i<12*intensity;i++){
            float x=w*(.08f+(i%7)*.135f)+w*.01f*(float)Math.sin(t*.4+i);
            float y=h*(.56f+(i%4)*.098f)+h*.018f*(float)Math.cos(t*.7+i);
            int alpha=(int)(85+100*Math.abs(Math.sin(t*.8+i*3.7)));
            p.setColor(Color.argb(alpha,255,224,133));c.drawCircle(x,y,Math.max(2,w*.0025f),p);
            p.setColor(Color.argb(alpha/4,255,213,88));c.drawCircle(x,y,w*.008f,p);
        }
    }
    private void lakeRipples(Canvas c,float w,float h,float t){
        p.setStrokeWidth(Math.max(1,w*.0008f));
        for(int i=0;i<20*intensity;i++){
            float yy=h*(.72f+.011f*i);
            float xx=w*(.07f+(i*.127f)% .78f)+w*.02f*(float)Math.sin(t*.7+i);
            float length=w*(.015f+.013f*(float)Math.abs(Math.sin(i+t)));
            p.setColor(Color.argb(28+(i%3)*13,184,224,255));c.drawLine(xx,yy,xx+length,yy,p);
        }
    }
    private void snow(Canvas c,float w,float h,float t,int count){
        for(int i=0;i<count*intensity;i++){
            float x=w*((i*.197f+.07f)%1f)+w*.014f*(float)Math.sin(t*.5+i);
            float y=h*((t*(.021f+(i%5)*.005f)+i*.169f)%1.12f);
            float r=Math.max(1.4f,w*(.0013f+(i%3)*.00045f));
            p.setColor(Color.argb(85+(i%3)*31,242,248,255));c.drawCircle(x,y,r,p);
        }
    }
}
